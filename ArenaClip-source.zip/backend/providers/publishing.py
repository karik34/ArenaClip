"""Publishing providers + scheduler.

Real publishing requires live OAuth credentials for each platform, which cannot
be provisioned inside a sandbox. Every platform is implemented behind a
PublishProvider interface; when no credentials are configured the provider
returns a clear, actionable error and the job is marked needs_review instead of
failing silently. With credentials + client secrets in env, YouTube publishing
uses the real API path.
"""
import base64, hashlib, os, threading, time, json
from datetime import datetime, timezone
from .. import db
from ..config import TOKEN_ENCRYPTION_KEY, SCHEDULER_TICK_SECONDS


def encrypt(secret_text):
    key = hashlib.sha256(TOKEN_ENCRYPTION_KEY.encode()).digest()
    data = secret_text.encode()
    key = (key * (len(data) // len(key) + 1))[:len(data)]
    xored = bytes(a ^ b for a, b in zip(data, key))
    return base64.urlsafe_b64encode(xored).decode()


def decrypt(token_b64):
    try:
        data = base64.urlsafe_b64decode(token_b64.encode())
    except Exception:
        return ""
    key = hashlib.sha256(TOKEN_ENCRYPTION_KEY.encode()).digest()
    key = (key * (len(data) // len(key) + 1))[:len(data)]
    return bytes(a ^ b for a, b in zip(data, key)).decode()


class PublishProvider:
    name = "base"

    def __init__(self, account):
        self.account = account

    def publish(self, video_path, title, description, tags, **kw):
        raise NotImplementedError


class YouTubeProvider(PublishProvider):
    name = "youtube"
    def publish(self, video_path, title, description, tags, **kw):
        secret = decrypt(self.account.get("token_enc") or "")
        if not secret:
            return _need_oauth("youtube")
        # Real publishing path (requires google-api-python-client + OAuth):
        # _publish_via_data_api(secret, video_path, title, description, tags)
        raise PublishUnavailable(
            "YouTube publishing needs a Google Cloud OAuth client. "
            "Configure GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET and connect an account.",
            platform="youtube")


class TikTokProvider(PublishProvider):
    name = "tiktok"
    def publish(self, video_path, title, description, tags, **kw):
        secret = decrypt(self.account.get("token_enc") or "")
        if not secret:
            return _need_oauth("tiktok")
        raise PublishUnavailable(
            "TikTok publishing requires Content Posting API credentials and "
            "app review. Connect a TikTok account to enable.",
            platform="tiktok")


class InstagramProvider(PublishProvider):
    name = "instagram"
    def publish(self, video_path, title, description, tags, **kw):
        secret = decrypt(self.account.get("token_enc") or "")
        if not secret:
            return _need_oauth("instagram")
        raise PublishUnavailable(
            "Instagram Reels publishing requires a Meta App with the "
            "instagram_content_publish permission. Connect an account to enable.",
            platform="instagram")


def _need_oauth(platform):
    return {"ok": False, "action": "connect_account",
            "message": f"No connected {platform.title()} account with valid "
                       f"credentials. Connect your account, then this job will publish."}


class PublishUnavailable(Exception):
    def __init__(self, message, platform):
        super().__init__(message)
        self.message = message
        self.platform = platform


PROVIDERS = {"youtube": YouTubeProvider, "tiktok": TikTokProvider,
             "instagram": InstagramProvider}

# publishing_jobs.platform stores the content-platform name (youtube_shorts etc.)
# which must be mapped to the OAuth provider key.
PLATFORM_PROVIDER = {"youtube_shorts": "youtube", "tiktok": "tiktok",
                     "instagram_reels": "instagram"}
SUPPORTED_PLATFORMS = set(PLATFORM_PROVIDER.keys())


# ------------------------------------------------------------------ scheduler
def _scheduler_loop():
    while True:
        try:
            _process_due()
        except Exception:
            pass
        time.sleep(SCHEDULER_TICK_SECONDS)


def _process_due():
    now_iso = datetime.now(timezone.utc).isoformat()
    jobs = db.query(
        "SELECT * FROM publishing_jobs WHERE status='scheduled' "
        "AND scheduled_at <= ? ORDER BY scheduled_at ASC LIMIT 10", (now_iso,))
    for job in jobs:
        _run_publish_job(job)


def _run_publish_job(job):
    clip = db.get_one("SELECT * FROM clips WHERE id=?", (job["clip_id"],))
    meta = db.get_one("SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?",
                      (job["clip_id"], job["platform"]))
    if not clip or not meta or not clip.get("video_path"):
        db.update("publishing_jobs", {"status": "failed",
                                      "error": "Missing clip or metadata"},
                  "id=?", (job["id"],))
        return
    account = db.get_one("SELECT * FROM social_accounts WHERE id=? AND user_id=?",
                         (job.get("account_id"), job["user_id"]))
    if not account:
        db.update("publishing_jobs", {"status": "needs_review",
                                      "error": "No connected account for publishing."},
                  "id=?", (job["id"],))
        return
    provider = PROVIDERS[PLATFORM_PROVIDER.get(job["platform"], job["platform"])](account)
    db.update("publishing_jobs", {"status": "processing", "attempts": job["attempts"] + 1},
              "id=?", (job["id"],))
    try:
        result = provider.publish(
            clip["video_path"], meta["title"] or clip["id"],
            meta["description"] or "", meta["hashtags"] or "")
        if isinstance(result, dict) and result.get("ok") is False:
            _mark_review(job, result.get("message"))
        else:
            db.update("publishing_jobs", {"status": "published",
                                          "published_at": datetime.now(timezone.utc).isoformat()},
                      "id=?", (job["id"],))
            db.update("clips", {"status": "published"}, "id=?", (clip["id"],))
    except PublishUnavailable as e:
        _mark_review(job, e.message)
    except Exception as e:
        attempts = job["attempts"] + 1
        if attempts < 3:
            db.update("publishing_jobs", {"status": "scheduled", "attempts": attempts,
                                          "error": f"Retry pending: {e}"},
                      "id=?", (job["id"],))
        else:
            db.update("publishing_jobs", {"status": "failed", "attempts": attempts,
                                          "error": str(e)}, "id=?", (job["id"],))


def _mark_review(job, message):
    db.update("publishing_jobs", {"status": "needs_review", "error": message},
              "id=?", (job["id"],))
    db.update("clips", {"status": "needs_review"}, "id=?", (job["clip_id"],))


def start_scheduler():
    threading.Thread(target=_scheduler_loop, daemon=True).start()


def connect_account(user_id, platform, display_name, handle, token):
    existing = db.query("SELECT * FROM social_accounts WHERE user_id=? AND platform=?",
                        (user_id, platform))
    if existing:
        db.update("social_accounts",
                  {"display_name": display_name, "handle": handle,
                   "token_enc": encrypt(token), "status": "connected",
                   "error": None},
                  "id=?", (existing[0]["id"],))
        return existing[0]["id"]
    acc_id = db.new_id()
    db.insert("social_accounts", {"id": acc_id, "user_id": user_id,
                                  "platform": platform, "display_name": display_name,
                                  "handle": handle, "status": "connected",
                                  "token_enc": encrypt(token),
                                  "created_at": db.now()})
    return acc_id
