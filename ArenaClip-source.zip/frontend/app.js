// ArenaClip SPA — vanilla ES module app
const state = {
  token: localStorage.getItem('token') || null,
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  route: { view: 'dashboard', params: {} },
  project: null,
  theme: localStorage.getItem('theme') || 'dark',
};

const $ = (sel, root = document) => root.querySelector(sel);
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
};

// ---------------------------------------------------------------- api client
async function api(path, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
  if (opts.body && !(opts.body instanceof FormData) && typeof opts.body !== 'string') {
    headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(path, { ...opts, headers });
  let data = null;
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) data = await res.json();
  else data = await res.text();
  if (!res.ok) {
    const msg = typeof data === 'string' ? data : (data && data.detail) || 'Request failed';
    throw new Error(msg);
  }
  return data;
}

function toast(msg, type = '') {
  const t = el('div', 'toast ' + type, msg);
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

function err(e) { toast(e.message || 'Something went wrong', 'error'); console.error(e); }

// ---------------------------------------------------------------- auth
function setAuth(data) {
  state.token = data.token; state.user = data.user;
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
}

function logout() {
  state.token = null; state.user = null;
  localStorage.removeItem('token'); localStorage.removeItem('user');
  route('login');
}

// ---------------------------------------------------------------- router
const routes = ['dashboard', 'projects', 'create', 'project', 'editor',
  'calendar', 'autopilot', 'brandkit', 'accounts', 'settings'];
function route(view, params = {}) {
  if (window._projectSSE) { window._projectSSE.close(); window._projectSSE = null; }
  state.route = { view, params };
  history.replaceState(null, '', '#' + view + (params.id ? '/' + params.id : ''));
  render();
  window.scrollTo(0, 0);
}

function navHTML(active) {
  const items = [
    ['dashboard', '◉', 'Dashboard'], ['projects', '▤', 'Projects'],
    ['create', '＋', 'Create'], ['calendar', '◷', 'Calendar'],
    ['autopilot', '✈', 'Autopilot'], ['brandkit', '❖', 'Brand Kit'],
    ['accounts', '⛁', 'Connected Accounts'], ['settings', '⚙', 'Settings'],
  ];
  return items.map(([v, ic, label]) =>
    `<a href="#${v}" class="${v === active ? 'active' : ''}" data-nav="${v}"><span class="ic">${ic}</span>${label}</a>`).join('');
}

function creditsBadge() {
  const c = state.user && state.user.subscription ? state.user.subscription.credits_remaining : '—';
  return `<div class="cred"><span>⚡</span><div><div style="font-weight:700">${Math.round(c)} credits</div><div style="color:var(--muted2);font-size:11px">${state.user ? state.user.plan : ''} plan</div></div></div>`;
}

// ---------------------------------------------------------------- render
function render() {
  const app = $('#app');
  if (!state.token) { renderAuth(app); return; }
  const v = state.route.view;
  app.innerHTML = `
    <div class="layout">
      <aside class="sidebar">
        <div class="brand"><div class="logo">✂</div>Arena<span style="color:var(--accent2)">Clip</span></div>
        <nav class="nav">${navHTML(v)}</nav>
        <div class="foot">
          <div style="margin-bottom:10px">${creditsBadge()}</div>
          <div style="display:flex;gap:8px;align-items:center">
            <span style="width:26px;height:26px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-size:12px">${(state.user.name||'U')[0].toUpperCase()}</span>
            <div style="flex:1"><div style="font-weight:600">${state.user.name}</div><div style="color:var(--muted2);font-size:11px">${state.user.email}</div></div>
            <button class="btn ghost sm" data-logout>⎋</button>
          </div>
        </div>
      </aside>
      <main class="main" id="view"></main>
    </div>`;
  bindNav();
  $('#app').querySelector('[data-logout]').onclick = logout;
  renderView($('#view'));
}

function bindNav() {
  document.querySelectorAll('[data-nav]').forEach(a => a.onclick = (e) => {
    e.preventDefault(); route(a.dataset.nav);
  });
}

const VIEWS = {
  dashboard: renderDashboard, projects: renderProjects, create: renderCreate,
  project: renderProject, editor: renderEditor, calendar: renderCalendar,
  autopilot: renderAutopilot, brandkit: renderBrandKit, accounts: renderAccounts,
  settings: renderSettings,
};
async function renderView(root) {
  try { await (VIEWS[state.route.view])(root); }
  catch (e) { err(e); root.innerHTML = empty('Something went wrong', e.message); }
}

function topbar(root, title, sub, actions = '') {
  root.innerHTML = `<div class="topbar"><div><h1>${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div><div class="row">${actions}</div></div>`;
}

const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const empty = (big, small) => `<div class="empty"><div class="big">${big}</div>${small ? `<p>${small}</p>` : ''}</div>`;

// ---------------------------------------------------------------- auth view
function renderAuth(app) {
  app.innerHTML = `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="brand" style="justify-content:center;margin-bottom:6px"><div class="logo">✂</div><span style="font-size:20px">Arena<span style="color:var(--accent2)">Clip</span></span></div>
        <div style="text-align:center;color:var(--muted);font-size:13px;margin-bottom:18px">Turn one long video into a library of short-form clips.</div>
        <div class="auth-tabs"><button class="on" id="tab-login">Log in</button><button id="tab-reg">Create account</button></div>
        <form id="authform">
          <div class="field" style="margin-bottom:12px"><label>Name (optional)</label><input id="f-name" placeholder="Your name" autocomplete="off"></div>
          <div class="field" style="margin-bottom:12px"><label>Email</label><input id="f-email" type="email" placeholder="you@example.com" required></div>
          <div class="field" style="margin-bottom:18px"><label>Password</label><input id="f-pass" type="password" placeholder="••••••••" minlength="6" required></div>
          <button class="btn primary" style="width:100%" type="submit" id="authbtn">Log in</button>
        </form>
        <div style="font-size:11.5px;color:var(--muted2);margin-top:14px;text-align:center">By continuing you agree to the terms. Videos are processed locally in this demo — no data leaves the server.</div>
      </div>
    </div>`;
  let mode = 'login';
  $('#tab-login').onclick = () => setMode('login');
  $('#tab-reg').onclick = () => setMode('register');
  function setMode(m) {
    mode = m;
    $('#tab-login').classList.toggle('on', m === 'login');
    $('#tab-reg').classList.toggle('on', m === 'register');
    $('#f-name').parentElement.style.display = m === 'register' ? 'flex' : 'none';
    $('#authbtn').textContent = m === 'login' ? 'Log in' : 'Create account';
    $('#authform h2')?.remove();
  }
  $('#f-name').parentElement.style.display = 'none';
  $('#authform').onsubmit = async (e) => {
    e.preventDefault();
    const body = { email: $('#f-email').value, password: $('#f-pass').value };
    if (mode === 'register') body.name = $('#f-name').value;
    try {
      const data = await api('/api/auth/' + (mode === 'login' ? 'login' : 'register'),
        { method: 'POST', body });
      setAuth(data); render();
    } catch (e) { err(e); }
  };
}

// ---------------------------------------------------------------- dashboard
async function renderDashboard(root) {
  topbar(root, 'Dashboard', 'Your content operation at a glance');
  const d = await api('/api/dashboard');
  const s = d.stats;
  root.insertAdjacentHTML('beforeend', `
    <div class="grid g4" style="margin-bottom:20px">
      <div class="stat"><div class="v">${d.projects.length}</div><div class="l">Projects</div></div>
      <div class="stat"><div class="v accent">${s.total_clips}</div><div class="l">Clips generated</div></div>
      <div class="stat"><div class="v">${s.published}</div><div class="l">Published</div></div>
      <div class="stat"><div class="v">${s.scheduled}</div><div class="l">Scheduled</div></div>
      <div class="stat"><div class="v">${s.processing}</div><div class="l">Processing</div></div>
      <div class="stat"><div class="v accent">${s.avg_score ?? '—'}</div><div class="l">Avg AI score</div></div>
      <div class="stat"><div class="v">${Math.round(d.credits_remaining)}</div><div class="l">Credits left</div></div>
      <div class="stat"><div class="v">${s.published + s.scheduled}</div><div class="l">Ready to publish</div></div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <h3 style="font-size:15px">Projects</h3>
      <button class="btn primary sm" data-nav="create">＋ New project</button>
    </div>`);
  const grid = el('div', 'grid g3');
  if (!d.projects.length) grid.innerHTML = empty('📭', 'Create your first project to start turning videos into clips.');
  for (const p of d.projects) grid.appendChild(projectCard(p));
  root.appendChild(grid);
  $('#view').querySelector('[data-nav="create"]').onclick = () => route('create');
  root.querySelectorAll('.project-card').forEach(c => c.onclick = () => route('project', { id: c.dataset.id }));
}

function projectCard(p) {
  const counts = p.counts || {};
  const chip = c => {
    const cls = { ready: 'ready', processing: 'processing', failed: 'failed',
      scheduled: 'scheduled', published: 'ready', draft: '', queued: 'processing' }[c] || '';
    return counts[c] ? `<span class="chip ${cls}">${counts[c]} ${c.replace('_', ' ')}</span>` : '';
  };
  const card = el('div', 'project-card', `
    <div class="name">${esc(p.name)}</div>
    <div class="meta">${p.clips} clips · ${esc(p.status)}</div>
    <div class="chips">${['ready', 'scheduled', 'published', 'processing', 'draft', 'failed'].map(chip).join('')}</div>`);
  card.dataset.id = p.id;
  return card;
}

// ---------------------------------------------------------------- projects
async function renderProjects(root) {
  topbar(root, 'Projects', 'All your repurposing projects');
  const projects = await api('/api/projects');
  const grid = el('div', 'grid g3');
  for (const p of projects) {
    const counts = {};
    (await api(`/api/projects/${p.id}/clips`)).forEach(c => counts[c.status] = (counts[c.status] || 0) + 1);
    const card = projectCard({ ...p, clips: Object.values(counts).reduce((a, b) => a + b, 0), counts });
    card.onclick = () => route('project', { id: p.id });
    grid.appendChild(card);
  }
  root.appendChild(grid);
}

// ---------------------------------------------------------------- create
const PLATFORMS = { youtube_shorts: 'YouTube Shorts', tiktok: 'TikTok', instagram_reels: 'Instagram Reels' };
const FOCUS_OPTS = ['Funny', 'Surprising', 'Controversial', 'Educational', 'Inspiring', 'Storytelling', 'Business advice', 'Strong opinions', 'Numbers & stats'];
const STYLES = [
  ['fast', 'Fast-paced', 'Punchy cuts, high energy, quick transitions'],
  ['balanced', 'Balanced', 'Natural pacing, moderate editing'],
  ['cinematic', 'Cinematic', 'Slower, dramatic, premium feel'],
  ['podcast', 'Podcast', 'Clean interview-style presentation'],
  ['minimal', 'Minimal', 'Little editing, pure content'],
];
const CAPTION_STYLES = ['classic', 'dynamic', 'bold', 'minimal', 'podcast', 'high_energy'];
const MUSIC_OPTS = [['none', 'None'], ['subtle', 'Subtle'], ['energetic', 'Energetic'], ['cinematic', 'Cinematic'], ['comedic', 'Comedic']];
const INTENSITY = [['none', 'None'], ['low', 'Low'], ['moderate', 'Moderate'], ['high', 'High']];

function defaultConfig() {
  return {
    num_clips: 8, min_duration: 25, max_duration: 55,
    platforms: ['youtube_shorts', 'tiktok', 'instagram_reels'],
    style: 'fast', focus: ['Funny', 'Surprising'], caption_style: 'dynamic',
    editing_intensity: 'high', music: 'energetic', music_volume: 0.16,
    min_score: 70, approval: 'automatic', publishing: 'manual',
    schedule: { interval_days: 1, time: '18:00' },
  };
}
let cfg = defaultConfig();
let sourceUrl = '';
let pendingUpload = null;

async function renderCreate(root) {
  topbar(root, 'Create Project', 'Give ArenaClip a video and tell it what to make');
  cfg = defaultConfig();
  sourceUrl = ''; pendingUpload = null;
  root.innerHTML = `
    <div class="grid" style="grid-template-columns:1.15fr .85fr;gap:18px;align-items:start">
      <div class="card" id="src-card">
        <h3>1 · Source video</h3>
        <div class="field" style="margin-bottom:14px"><label>Video URL</label>
          <input id="src-url" placeholder="https://youtube.com/watch?v=... or any direct video link" value="">
          <div class="hint">YouTube, Vimeo, TikTok, direct MP4 links, etc. (where legally available)</div></div>
        <div style="text-align:center;color:var(--muted2);font-size:12px;margin:6px 0">— or —</div>
        <div class="dropzone" id="dz">⭳ &nbsp;Drag & drop a video here or click to browse<br><span style="font-size:12px">MP4, MOV, MKV, WebM · up to 2 GB</span>
          <input type="file" id="file" accept="video/*" hidden></div>
        <div id="file-info"></div>
      </div>
      <div class="card">
        <h3>2 · AI configuration</h3>
        <div class="form-grid">
          <div class="field"><label>Number of clips</label><input id="c-num" type="number" min="1" max="30" value="${cfg.num_clips}"></div>
          <div class="field"><label>Min clip (s)</label><input id="c-min" type="number" value="${cfg.min_duration}"></div>
          <div class="field"><label>Max clip (s)</label><input id="c-max" type="number" value="${cfg.max_duration}"></div>
          <div class="field"><label>Minimum AI score</label><input id="c-minscore" type="number" min="0" max="100" value="${cfg.min_score}"></div>
          <div class="field full"><label>Target platforms</label><div id="plat-options" class="row" style="flex-wrap:wrap"></div></div>
          <div class="field full"><label>Content style</label><select id="c-style">${STYLES.map(([v, n, d]) => `<option value="${v}">${n} — ${d}</option>`).join('')}</select></div>
          <div class="field full"><label>Focus on moments that are</label><div id="focus-options" class="chips"></div></div>
          <div class="field"><label>Caption style</label><select id="c-caption">${CAPTION_STYLES.map(c => `<option>${c}</option>`).join('')}</select></div>
          <div class="field"><label>Editing intensity</label><select id="c-intensity">${INTENSITY.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select></div>
          <div class="field"><label>Background music</label><select id="c-music">${MUSIC_OPTS.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select></div>
          <div class="field"><label>Clip approval</label><select id="c-approval"><option value="automatic">Automatic</option><option value="manual">Require approval</option></select></div>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:18px">
      <h3>3 · Publishing</h3>
      <div class="form-grid">
        <div class="field"><label>Publishing mode</label><select id="c-pub"><option value="manual">Manual — I publish myself</option><option value="automatic">Automatic via connected accounts</option></select></div>
        <div class="field"><label>Schedule (if publishing)</label><select id="c-sched"><option value="daily">1 clip every day</option><option value="weekly">1 clip per week</option><option value="never">Don't schedule</option></select></div>
        <div class="field"><label>Posting time (local)</label><input id="c-time" type="time" value="${cfg.schedule.time}"></div>
        <div class="field"><label>Project name</label><input id="c-name" placeholder="Podcast Episode #42" value=""></div>
      </div>
      <div style="margin-top:18px;display:flex;gap:12px;align-items:center">
        <button class="btn primary" id="go">⚡ Start processing</button>
        <span id="create-status" class="hint"></span>
      </div>
    </div>`;
  // platform chips
  const platBox = $('#plat-options');
  for (const [v, n] of Object.entries(PLATFORMS)) {
    const b = el('button', 'chip', n);
    b.dataset.v = v; b.classList.toggle('ready', cfg.platforms.includes(v));
    b.onclick = () => { const i = cfg.platforms.indexOf(v); i >= 0 ? cfg.platforms.splice(i, 1) : cfg.platforms.push(v); b.classList.toggle('ready', cfg.platforms.includes(v)); };
    platBox.appendChild(b);
  }
  // focus chips
  const focBox = $('#focus-options');
  FOCUS_OPTS.forEach(f => {
    const b = el('button', 'chip', f);
    b.classList.toggle('ready', cfg.focus.includes(f));
    b.onclick = () => { const i = cfg.focus.indexOf(f); i >= 0 ? cfg.focus.splice(i, 1) : cfg.focus.push(f); b.classList.toggle('ready', cfg.focus.includes(f)); };
    focBox.appendChild(b);
  });

  const dz = $('#dz'), fi = $('#file');
  dz.onclick = () => fi.click();
  fi.onchange = () => { if (fi.files[0]) { pendingUpload = fi.files[0]; showFile(); } };
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag'));
  dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('drag'); pendingUpload = e.dataTransfer.files[0]; showFile(); });
  function showFile() {
    $('#file-info').innerHTML = `<div style="margin-top:10px;font-weight:600">✓ ${esc(pendingUpload.name)} (${(pendingUpload.size/1e6).toFixed(1)} MB)</div>`;
    sourceUrl = '';
  }
  $('#src-url').oninput = e => { sourceUrl = e.target.value.trim(); pendingUpload = null; $('#file-info').innerHTML = ''; };

  $('#go').onclick = async () => {
    if (!sourceUrl && !pendingUpload) { toast('Provide a video URL or upload a file', 'error'); return; }
    const name = $('#c-name').value.trim() || (sourceUrl ? new URL(sourceUrl).hostname : pendingUpload.name) ;
    cfg.num_clips = +$('#c-num').value; cfg.min_duration = +$('#c-min').value;
    cfg.max_duration = +$('#c-max').value; cfg.min_score = +$('#c-minscore').value;
    cfg.style = $('#c-style').value; cfg.caption_style = $('#c-caption').value;
    cfg.editing_intensity = $('#c-intensity').value; cfg.music = $('#c-music').value;
    cfg.approval = $('#c-approval').value; cfg.publishing = $('#c-pub').value;
    cfg.schedule.interval_days = $('#c-sched').value === 'weekly' ? 7 : 1;
    cfg.schedule.time = $('#c-time').value || '18:00';
    const goBtn = $('#go'); goBtn.disabled = true; goBtn.textContent = 'Creating…';
    try {
      const p = await api('/api/projects', { method: 'POST', body: { name, config: cfg, source_url: sourceUrl || null } });
      $('#create-status').textContent = 'Project created — ingesting video…';
      if (pendingUpload) {
        const fd = new FormData(); fd.append('file', pendingUpload);
        await api(`/api/projects/${p.id}/ingest/upload`, { method: 'POST', body: fd });
      } else {
        await api(`/api/projects/${p.id}/ingest/url`, { method: 'POST', body: { url: sourceUrl } });
      }
      toast('Processing started', 'success');
      route('project', { id: p.id });
    } catch (e) { err(e); goBtn.disabled = false; goBtn.textContent = '⚡ Start processing'; }
  };
}

// ---------------------------------------------------------------- project
async function renderProject(root) {
  const pid = state.route.params.id;
  const p = await api(`/api/projects/${pid}`);
  const config = p.config || {};
  topbar(root, esc(p.name), `Status: <span class="badge ${p.status === 'ready' ? 'green' : p.status === 'processing' ? 'amber' : 'red'}">${esc(p.status)}</span> &nbsp;·&nbsp; ${(p.source_video && p.source_video.duration || 0).toFixed(1)}s source`);
  root.innerHTML += `<div class="row" style="margin-bottom:18px">
      <button class="btn ghost" data-back>← Projects</button>
      <button class="btn" id="download-all">⬇ Download all ready clips</button>
      <span class="grow"></span><span class="hint" id="proj-hint"></span>
    </div><div id="proj-body"></div>`;
  root.querySelector('[data-back]').onclick = () => route('projects');

  const body = $('#proj-body');
  if (['processing', 'draft'].includes(p.status)) {
    body.innerHTML = `<div class="card"><h3>Processing pipeline</h3><div id="stages"></div>
      <div class="progress-note">Live updates stream from the processing worker. This is real progress from real jobs — not a fake spinner.</div></div>
      <div style="margin-top:18px"><h3 style="margin-bottom:10px">Clips</h3><div class="grid g3" id="clipgrid"></div></div>`;
    renderStages($('#stages'));
    // SSE live progress
    const evt = new EventSource(`/api/projects/${pid}/events`);
    evt.onmessage = (e) => {
      const d = JSON.parse(e.data);
      if (d.stage_index != null) updateStage(d);
      loadClips();
    };
    window._projectSSE = evt;
    evt.onerror = () => {};
  } else {
    body.innerHTML = `<div class="grid g3" id="clipgrid"></div>`;
  }
  loadClips();
  $('#download-all').onclick = async () => {
    const clips = await api(`/api/projects/${pid}/clips`);
    const ready = clips.filter(c => c.status === 'ready' && c.video_url);
    if (!ready.length) { toast('No ready clips to download yet', 'error'); return; }
    for (const c of ready) { window.open(c.video_url, '_blank'); }
  };
  async function loadClips() {
    try {
      const clips = await api(`/api/projects/${pid}/clips`);
      const grid = $('#clipgrid'); if (!grid) return;
      if (!clips.length) { grid.innerHTML = empty('⏳', 'Analyzing your video. Clips will appear here as they are found and rendered.'); return; }
      grid.innerHTML = '';
      clips.forEach(c => grid.appendChild(clipCard(c)));
    } catch (e) {}
  }
}

function renderStages(box) {
  const names = ['Downloading video', 'Extracting audio', 'Transcribing', 'Analyzing content', 'Finding viral moments', 'Creating clips', 'Rendering'];
  box.innerHTML = names.map((n, i) => `
    <div class="stage" data-stage="${i}"><div class="dot" data-dot>◌</div>
      <div><div class="sname">${n}</div><div class="smsg" data-msg></div></div>
      <div class="bar" data-bar><i style="width:0%"></i></div><div class="pct" data-pct>0%</div></div>`).join('');
  box.querySelectorAll('[data-stage]').forEach(s => s.classList.remove('done', 'active', 'failed'));
}
function updateStage(d) {
  const box = $('#stages'); if (!box) return;
  const all = [...box.querySelectorAll('[data-stage]')];
  all.forEach(s => s.classList.remove('done', 'active', 'failed'));
  const idx = Math.min(d.stage_index, all.length - 1);
  const cur = all[idx];
  if (cur) {
    cur.classList.add(d.state === 'failed' ? 'failed' : 'active');
    cur.querySelector('[data-msg]').textContent = d.message || '';
    const pct = cur.querySelector('[data-pct]');
    pct.textContent = Math.round(d.progress) + '%';
    cur.querySelector('[data-bar]>i').style.width = Math.round(d.progress) + '%';
    cur.querySelector('[data-dot]').textContent = d.progress >= 100 ? '✓' : '▣';
    if (d.progress >= 100) { cur.classList.remove('active'); cur.classList.add('done'); }
    if (d.stage === 'Complete') all.forEach(s => { s.classList.add('done'); s.querySelector('[data-dot]').textContent = '✓'; });
  }
  $('#proj-hint') && ($('#proj-hint').textContent = d.message || '');
}

function clipCard(c) {
  const s = c.scores || {};
  const scoreColor = c.score >= 75 ? 'var(--green)' : c.score >= 60 ? 'var(--amber)' : 'var(--muted2)';
  const card = el('div', 'clip-card');
  card.innerHTML = `
    <div class="thumb">
      ${c.thumbnail_url ? `<img src="${c.thumbnail_url}">` : `<span style="font-size:34px">🎬</span>`}
      <div class="score-badge" style="color:#fff">${c.score ?? '—'}<span style="font-size:9px">/100</span></div>
      <div class="dur">${(c.duration || 0).toFixed(0)}s</div>
    </div>
    <div class="body">
      <div class="hook">${esc(c.hook_snapshot || c.transcript || 'Clip ' + c.id.slice(0, 6))}</div>
      <div class="status"><span class="status-dot ${esc(c.status)}"></span>${esc(c.status.replace('_', ' '))}</div>
      <div style="margin-top:10px;display:flex;gap:6px">
        ${c.status === 'ready' ? `<button class="btn sm" data-view>Open</button>` : c.status === 'processing' ? `<span class="hint">rendering…</span>` : ''}
      </div>
    </div>`;
  card.querySelector('[data-view]')?.addEventListener('click', () => route('editor', { id: c.id }));
  return card;
}

// ---------------------------------------------------------------- editor
async function renderEditor(root) {
  const cid = state.route.params.id;
  const c = await api(`/api/clips/${cid}`);
  const project = await api(`/api/projects/${c.project_id}`).catch(() => null);
  const meta = c.metadata || [];
  topbar(root, 'Clip Editor', `AI score ${c.score}/100 — ${esc(c.score_label || '')}`);
  root.innerHTML = `
    <div class="row" style="margin-bottom:16px"><button class="btn ghost" data-back>← Back to project</button>
      <span class="grow"></span>
      <button class="btn" data-render>↻ Re-render</button>
      <button class="btn primary" data-download>⬇ Download MP4</button>
    </div>
    <div class="grid" style="grid-template-columns:1fr 1fr;gap:18px;align-items:start">
      <div>
        <div class="editor-preview">${c.video_url ? `<video src="${c.video_url}" controls playsinline></video>` : '<div style="display:grid;place-items:center;height:100%;color:var(--muted)">No render yet — click Re-render</div>'}</div>
        <div class="card" style="margin-top:16px"><h3>Scores</h3><div class="scores" id="scores"></div>
        <p class="hint" style="margin-top:10px">${esc(c.reason || '')}</p></div>
      </div>
      <div>
        <div class="tabs">
          <button class="tab active" data-tab="edit">Edit</button>
          <button class="tab" data-tab="metadata">Metadata</button>
          <button class="tab" data-tab="publish">Publish</button>
          <button class="tab" data-tab="transcript">Transcript</button>
        </div>
        <div id="panel"></div>
      </div>
    </div>`;
  root.querySelector('[data-back]').onclick = () => route('project', { id: c.project_id });
  root.querySelector('[data-download]').onclick = async () => { try { window.location.href = `/api/clips/${cid}/download`; } catch (e) { toast('Render the clip first', 'error'); } };
  root.querySelector('[data-render]').onclick = async () => {
    await api(`/api/clips/${cid}/render`, { method: 'POST' });
    toast('Re-rendering… this may take a moment', 'success');
    setTimeout(() => renderEditor(root), 2500);
  };

  // scores
  const sc = c.scores || {};
  const order = ['hook_strength', 'curiosity', 'emotional_intensity', 'entertainment', 'information', 'standalone_context', 'pacing', 'shareability', 'originality', 'ending_quality'];
  $('#scores').innerHTML = order.map(k => `<div class="score-item"><div class="l">${esc(k.replace(/_/g, ' '))}</div><div class="v">${sc[k] ?? '—'}</div><div class="mbar"><i style="width:${sc[k] || 0}%"></i></div></div>`).join('');

  const tabs = [...root.querySelectorAll('.tab')];
  const showTab = (t) => { tabs.forEach(x => x.classList.toggle('active', x === t)); loadPanel(t.dataset.tab); };
  tabs.forEach(t => t.onclick = () => showTab(t));
  loadPanel('edit');

  function loadPanel(tab) {
    const box = $('#panel');
    if (tab === 'edit') panelEdit(box, c);
    else if (tab === 'metadata') panelMetadata(box, c, meta);
    else if (tab === 'publish') panelPublish(box, c);
    else panelTranscript(box, c);
  }
}

function panelEdit(box, c) {
  box.innerHTML = `
    <div class="field" style="margin-bottom:14px"><label>Start time (s)</label><input type="number" id="e-start" step="0.1" min="0" value="${c.start_ts}"></div>
    <div class="field" style="margin-bottom:14px"><label>End time (s)</label><input type="number" id="e-end" step="0.1" value="${c.end_ts}"></div>
    <div class="field" style="margin-bottom:14px"><label>Caption style</label><select id="e-cap">${CAPTION_STYLES.map(x => `<option ${x === (c.caption_style || 'dynamic') ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
    <div class="field" style="margin-bottom:14px"><label>Editing intensity (jump cuts)</label><select id="e-int">${INTENSITY.map(([v, n]) => `<option value="${v}" ${v === (c.editing_intensity || 'moderate') ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="field" style="margin-bottom:14px"><label>Music</label><select id="e-music">${MUSIC_OPTS.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select></div>
    <div class="field" style="margin-bottom:18px"><label>Music volume</label><input type="range" id="e-vol" min="0" max="0.5" step="0.02" value="${c.music_volume ?? 0.16}"></div>
    <button class="btn primary" data-save>Save changes & re-render</button>
    <p class="hint" style="margin-top:8px">Changing start/end or styles requires a re-render to take effect on the video.</p>`;
  box.querySelector('[data-save]').onclick = async () => {
    const body = { start_ts: +$('#e-start').value, end_ts: +$('#e-end').value, caption_style: $('#e-cap').value, editing_intensity: $('#e-int').value, music_volume: +$('#e-vol').value };
    try {
      await api(`/api/clips/${c.id}`, { method: 'PATCH', body });
      // persist style choices on clip for renderer
      toast('Saved — re-rendering…', 'success');
      await api(`/api/clips/${c.id}/render`, { method: 'POST' });
      setTimeout(() => renderEditor(box.closest('.main')), 3000);
    } catch (e) { err(e); }
  };
}

function panelMetadata(box, c, metas) {
  const platforms = metas.length ? metas.map(m => m.platform) : Object.keys(PLATFORMS);
  let plat = metas[0]?.platform || 'youtube_shorts';
  box.innerHTML = `
    <div class="row" style="margin-bottom:14px;flex-wrap:wrap">${platforms.map(p => `<button class="btn sm ${p === plat ? 'primary' : ''}" data-plat="${p}">${PLATFORMS[p] || p}</button>`).join('')}
    <button class="btn sm ghost" data-regen>↻ Regenerate</button></div>
    <div id="md-body"></div>`;
  box.querySelectorAll('[data-plat]').forEach(b => b.onclick = () => { plat = b.dataset.plat; renderMd(); });
  box.querySelector('[data-regen]').onclick = async () => { await api(`/api/clips/${c.id}/metadata/regenerate`, { method: 'POST' }); toast('Metadata regenerated', 'success'); renderEditor($('.main')); };
  renderMd();
  async function renderMd() {
    let m = metas.find(x => x.platform === plat) || { title: '', description: '', hashtags: '', cta: '' };
    if (!m.title) { // not generated yet for this platform
      try { const d = await api(`/api/clips/${c.id}`); m = (d.metadata.find(x => x.platform === plat)) || { title: '', description: '', hashtags: '', cta: '' }; } catch (e) {}
    }
    const body = $('#md-body');
    body.innerHTML = `
      <div class="field" style="margin-bottom:12px"><label>Title</label><input id="md-title" value="${esc(m.title || '')}"></div>
      <div class="field" style="margin-bottom:12px"><label>Description / caption</label><textarea id="md-desc" rows="4">${esc(m.description || '')}</textarea></div>
      <div class="field" style="margin-bottom:12px"><label>Hashtags</label><input id="md-tags" value="${esc(m.hashtags || '')}"></div>
      <div class="field" style="margin-bottom:12px"><label>CTA</label><input id="md-cta" value="${esc(m.cta || '')}"></div>
      <button class="btn" data-save-md>Save metadata</button>`;
    body.querySelector('[data-save-md]').onclick = async () => {
      await api(`/api/clips/${c.id}/metadata`, { method: 'PATCH', body: { platform: plat, title: $('#md-title').value, description: $('#md-desc').value, hashtags: $('#md-tags').value, cta: $('#md-cta').value } });
      toast('Saved', 'success');
    };
  }
}

async function panelPublish(box, c) {
  const accounts = await api('/api/accounts');
  const now = new Date();
  const ts = now.toISOString().slice(0, 16);
  box.innerHTML = `
    <div class="field" style="margin-bottom:12px"><label>Platform</label><select id="p-plat">${Object.keys(PLATFORMS).map(p => `<option value="${p}">${PLATFORMS[p]}</option>`).join('')}</select></div>
    <div class="field" style="margin-bottom:12px"><label>Account</label><select id="p-acc">
      ${accounts.length ? accounts.map(a => `<option value="${a.id}">${a.display_name} (${a.platform})</option>`).join('') : '<option value="">No accounts connected</option>'}
    </select></div>
    <div class="field" style="margin-bottom:12px"><label>Schedule date/time</label><input type="datetime-local" id="p-time" value="${ts}"></div>
    <button class="btn primary" data-queue>Schedule to calendar</button>
    <button class="btn" data-queue-now style="margin-top:8px">Queue now</button>
    ${!accounts.length ? `<p class="hint" style="margin-top:10px">Connect an account in Connected Accounts. Real publishing requires live OAuth credentials (see docs); scheduled jobs without a valid connected account are marked "Needs review" rather than silently dropped.</p>` : ''}`;
  box.querySelector('[data-queue]').onclick = async () => {
    await api(`/api/clips/${c.id}/queue`, { method: 'POST', body: { platform: $('#p-plat').value, account_id: $('#p-acc').value || null, scheduled_at: new Date($('#p-time').value).toISOString() } });
    toast('Scheduled — see Calendar', 'success'); route('calendar');
  };
  box.querySelector('[data-queue-now]').onclick = async () => {
    await api(`/api/clips/${c.id}/queue`, { method: 'POST', body: { platform: $('#p-plat').value, account_id: $('#p-acc').value || null, scheduled_at: new Date().toISOString() } });
    toast('Queued', 'success'); route('calendar');
  };
}

function panelTranscript(box, c) {
  const t = c.transcript || 'No transcript captured for this clip.';
  box.innerHTML = `<div class="transcript">${esc(t)}</div>
    <p class="hint" style="margin-top:8px">Captions are generated from word-level timestamps. Editing here isn't yet wired to a re-render; use Re-render after changing timing in the Edit tab.</p>`;
}

// ---------------------------------------------------------------- calendar
async function renderCalendar(root) {
  topbar(root, 'Content Calendar', 'Scheduled & published clips');
  const jobs = await api('/api/calendar');
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  root.innerHTML += `<div class="card"><div class="cal" id="calgrid"></div></div>
    <div style="margin-top:18px"><h3 style="margin-bottom:10px">All publishing jobs</h3><table class="list"><thead><tr><th>Title</th><th>Platform</th><th>Scheduled</th><th>Status</th><th>Error</th></tr></thead><tbody id="jobrows"></tbody></table></div>`;
  const first = new Date(); first.setDate(1);
  const yr = first.getFullYear(), mo = first.getMonth();
  const startDay = new Date(yr, mo, 1);
  const daysInMonth = new Date(yr, mo + 1, 0).getDate();
  const lead = startDay.getDay();
  const cal = $('#calgrid');
  cal.innerHTML = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="day"><div class="dnum">${d}</div></div>`).join('');
  for (let i = 0; i < lead; i++) cal.innerHTML += `<div class="day"></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const iso = `${yr}-${String(mo + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dayJobs = jobs.filter(j => (j.scheduled_at || '').slice(0, 10) === iso);
    const day = el('div', 'day');
    day.innerHTML = `<div class="dnum">${d}</div>` + dayJobs.map(j => `
      <div class="event ${j.status}" title="${esc(j.error || '')}" data-job="${j.id}">
        ${j.thumb_url ? `<img src="${j.thumb_url}" style="width:26px;height:46px;object-fit:cover;border-radius:4px;float:left;margin-right:5px">` : ''}
        ${esc((j.title || 'Clip').slice(0, 22))}
        <div style="color:var(--muted2)">${j.platform.split('_')[0]}</div>
      </div>`).join('');
    cal.appendChild(day);
  }
  const rows = $('#jobrows');
  rows.innerHTML = jobs.length ? jobs.map(j => `<tr>
    <td>${esc(j.title || j.clip_id.slice(0, 8))}</td>
    <td>${esc(j.platform.replace('_', ' '))}</td>
    <td>${esc((j.scheduled_at || '').replace('T', ' ').slice(0, 16))}</td>
    <td><span class="badge ${j.status === 'published' ? 'green' : j.status === 'failed' ? 'red' : j.status === 'needs_review' ? 'amber' : 'blue'}">${esc(j.status.replace('_', ' '))}</span></td>
    <td style="color:var(--muted2);font-size:12px">${esc((j.error || '').slice(0, 60))}</td></tr>`).join('')
    : '<tr><td colspan="5" style="text-align:center;color:var(--muted)">No publishing jobs yet. Open a clip and schedule it.</td></tr>';
}

// ---------------------------------------------------------------- autopilot
async function renderAutopilot(root) {
  topbar(root, 'Autopilot', 'Automated repurposing workflows');
  const autos = await api('/api/automations');
  root.innerHTML += `<div class="grid" style="grid-template-columns:1fr 1fr;gap:18px;align-items:start">
    <div class="card">
      <h3>New automation</h3>
      <div class="field" style="margin-bottom:12px"><label>Workflow name</label><input id="a-name" placeholder="My podcast channel"></div>
      <div class="field" style="margin-bottom:12px"><label>Source (YouTube channel or video URL)</label><input id="a-src" placeholder="https://youtube.com/@channel or .../video"></div>
      <div class="field" style="margin-bottom:12px"><label>Trigger</label><select id="a-trig"><option value="new_video">When a new video is uploaded</option></select></div>
      <div class="form-grid">
        <div class="field"><label>Clips per video</label><input type="number" id="a-num" value="8"></div>
        <div class="field"><label>Min duration (s)</label><input type="number" id="a-min" value="25"></div>
        <div class="field"><label>Max duration (s)</label><input type="number" id="a-max" value="55"></div>
        <div class="field"><label>Min score</label><input type="number" id="a-score" value="75"></div>
      </div>
      <div class="field" style="margin-bottom:12px"><label>Caption style</label><select id="a-cap">${CAPTION_STYLES.map(x => `<option>${x}</option>`).join('')}</select></div>
      <div class="field" style="margin-bottom:12px"><label>Editing intensity</label><select id="a-int">${INTENSITY.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select></div>
      <div class="field" style="margin-bottom:14px"><label>Approval</label><select id="a-approve"><option value="automatic">Automatic</option><option value="manual">Manual review</option></select></div>
      <button class="btn primary" data-save>Create automation</button>
      <p class="hint" style="margin-top:10px">Autopilot polls the source for new uploads. New videos automatically enter the pipeline → clips → queue → schedule. Enable after creation.</p>
    </div>
    <div>
      <h3 style="margin-bottom:12px">Active workflows</h3>
      <div id="autolist"></div>
    </div></div>`;
  const list = $('#autolist');
  function renderList() {
    list.innerHTML = autos.length ? autos.map(a => `
      <div class="card" style="margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:10px">
          <div class="toggle ${a.enabled ? 'on' : ''}" data-toggle="${a.id}"></div>
          <div style="flex:1"><div style="font-weight:700">${esc(a.name)}</div>
          <div style="color:var(--muted);font-size:12px">${esc(a.source_url)} · ${a.config.num_clips || 8} clips · ${esc(a.config.caption_style || 'dynamic')}</div></div>
          <span class="badge ${a.enabled ? 'green' : 'gray'}">${a.enabled ? 'Active' : 'Off'}</span>
        </div></div>`).join('') : empty('✈', 'No workflows yet.');
    list.querySelectorAll('[data-toggle]').forEach(t => t.onclick = async () => {
      const on = !t.classList.contains('on');
      t.classList.toggle('on', on);
      await api(`/api/automations/${t.dataset.toggle}`, { method: 'PATCH', body: { enabled: on } });
      toast(on ? 'Autopilot enabled' : 'Autopilot disabled', 'success');
    });
  }
  renderList();
  $('#autolist').parentElement.insertAdjacentHTML('beforeend', `
    <div class="card" style="margin-top:6px"><h3>How Autopilot runs</h3>
    <div class="progress-note">New video → detect → download → transcribe → analyze → find moments → score → select → edit → metadata → queue → schedule → publish.<br>Each step is a retryable background job. Publishing needs a connected account with live OAuth credentials.</div></div>`);
  root.querySelector('[data-save]').onclick = async () => {
    const cfg = {
      num_clips: +$('#a-num').value, min_duration: +$('#a-min').value, max_duration: +$('#a-max').value,
      min_score: +$('#a-score').value, caption_style: $('#a-cap').value,
      editing_intensity: $('#a-int').value, approval: $('#a-approve').value,
      platforms: ['youtube_shorts', 'tiktok', 'instagram_reels'], music: 'energetic',
    };
    try {
      await api('/api/automations', { method: 'POST', body: { name: $('#a-name').value, source_url: $('#a-src').value, config: cfg } });
      toast('Automation created', 'success'); renderAutopilot(root);
    } catch (e) { err(e); }
  };
}

// ---------------------------------------------------------------- brand kit
async function renderBrandKit(root) {
  topbar(root, 'Brand Kit', 'Reusable brand styling for every clip');
  const kits = await api('/api/brandkit');
  const k = kits[0]?.config || { name: '', primary_font: 'Arial', caption_font: 'Arial', caption_color: '#FFFFFF', caption_animation: 'dynamic', default_cta: 'Follow for more.', accent: '00C9FF' };
  root.innerHTML += `<div class="card" style="max-width:640px">
    <div class="form-grid">
      <div class="field"><label>Brand name</label><input id="b-name" value="${esc(k.name)}"></div>
      <div class="field"><label>Primary font</label><select id="b-font">${['Arial', 'Arial Black', 'DejaVu Sans', 'Impact', 'Inter'].map(f => `<option ${f === k.primary_font ? 'selected' : ''}>${f}</option>`).join('')}</select></div>
      <div class="field"><label>Caption font</label><select id="b-capfont">${['Arial', 'Arial Black', 'DejaVu Sans', 'Impact', 'Inter'].map(f => `<option ${f === k.caption_font ? 'selected' : ''}>${f}</option>`).join('')}</select></div>
      <div class="field"><label>Caption color</label><input type="color" id="b-color" value="${k.caption_color}"></div>
      <div class="field"><label>Caption animation</label><select id="b-anim">${['dynamic', 'static', 'pop', 'fade'].map(a => `<option ${a === k.caption_animation ? 'selected' : ''}>${a}</option>`).join('')}</select></div>
      <div class="field"><label>Accent color</label><input type="color" id="b-accent" value="#${k.accent || '00C9FF'}"></div>
      <div class="field full"><label>Default CTA</label><input id="b-cta" value="${esc(k.default_cta)}"></div>
    </div>
    <div style="margin-top:16px;display:flex;gap:10px"><button class="btn primary" data-save>Save brand kit</button>
      <button class="btn" data-apply>Apply to project re-render</button></div>
    <p class="hint" style="margin-top:8px">Every rendered clip automatically uses these brand settings.</p></div>`;
  root.querySelector('[data-save]').onclick = async () => {
    const config = { name: $('#b-name').value, primary_font: $('#b-font').value, caption_font: $('#b-capfont').value, caption_color: $('#b-color').value, caption_animation: $('#b-anim').value, accent: $('#b-accent').value.slice(1), default_cta: $('#b-cta').value };
    await api('/api/brandkit', { method: 'PUT', body: { name: config.name, config } });
    toast('Brand kit saved', 'success');
  };
  root.querySelector('[data-apply]').onclick = async () => { await api('/api/brandkit', { method: 'PUT', body: { name: kits[0]?.name || 'My Brand', config: { name: $('#b-name').value, primary_font: $('#b-font').value, caption_font: $('#b-capfont').value, caption_color: $('#b-color').value, caption_animation: $('#b-anim').value, accent: $('#b-accent').value.slice(1), default_cta: $('#b-cta').value } } }); toast('Saved — re-render clips to apply', 'success'); };
}

// ---------------------------------------------------------------- accounts
async function renderAccounts(root) {
  topbar(root, 'Connected Accounts', 'OAuth connections for publishing');
  const accs = await api('/api/accounts');
  const defs = [
    ['youtube', 'YouTube', 'Publish Shorts to your channel'],
    ['tiktok', 'TikTok', 'Publish clips to TikTok'],
    ['instagram', 'Instagram', 'Publish Reels to Instagram'],
  ];
  root.innerHTML += `<div class="grid g3">` + defs.map(([plat, name, desc]) => {
    const a = accs.find(x => x.platform === plat);
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div style="font-weight:700">${name}</div>
        <span class="badge ${a ? 'green' : 'gray'}">${a ? 'Connected' : 'Not connected'}</span></div>
      <p class="hint" style="margin:8px 0 14px">${desc}</p>
      ${a ? `<div style="font-size:13px;margin-bottom:12px">${esc(a.display_name)} ${a.handle ? '· @' + esc(a.handle) : ''}<br><span style="color:var(--muted2)">status: ${a.status}</span></div>
        <button class="btn sm danger" data-disc="${a.id}">Disconnect</button>`
      : `<button class="btn sm" data-connect="${plat}">Connect (demo)</button>`}
    </div>`;
  }).join('') + `</div>
  <div class="card" style="margin-top:18px"><h3>About publishing & OAuth</h3>
    <p class="hint">This demo connects accounts in demo mode (tokens are stored encrypted, never as plaintext). Real publishing to YouTube/TikTok/Instagram requires live OAuth client credentials from each platform, which cannot be provisioned inside this sandbox. The publishing layer is fully abstracted behind PublishProvider — swap in the real SDK (google-api-python-client, etc.) with your credentials. Jobs scheduled without a valid account are marked "Needs review" with a clear explanation instead of failing silently.</p></div>`;
  root.querySelectorAll('[data-connect]').forEach(b => b.onclick = async () => {
    await api('/api/accounts', { method: 'POST', body: { platform: b.dataset.connect, display_name: nameFor(b.dataset.connect), token: 'demo-token-' + Math.random().toString(36).slice(2) } });
    toast('Account connected (demo mode)', 'success'); renderAccounts(root);
  });
  root.querySelectorAll('[data-disc]').forEach(b => b.onclick = async () => { await api('/api/accounts/' + b.dataset.disc, { method: 'DELETE' }); toast('Disconnected', 'success'); renderAccounts(root); });
}
const nameFor = p => ({ youtube: 'My YouTube Channel', tiktok: 'My TikTok', instagram: 'My Instagram' }[p]);

// ---------------------------------------------------------------- settings
async function renderSettings(root) {
  topbar(root, 'Settings', 'Account, plan & usage');
  const sub = await api('/api/subscription');
  const s = sub.subscription || {};
  root.innerHTML += `<div class="grid g2">
    <div class="card"><h3>Subscription</h3>
      <div style="display:flex;align-items:center;gap:14px">
        <div><div style="font-size:22px;font-weight:800">${s.plan || 'free'}</div>
        <div class="hint">${Math.round(s.credits_remaining || 0)} credits remaining</div></div>
        <div class="grow"></div>
        <span class="badge ${s.status === 'active' ? 'green' : 'amber'}">${s.status}</span>
      </div>
      <div style="margin-top:16px"><b style="font-size:13px">Usage</b>
      <table class="list" style="margin-top:8px"><tbody>
        ${sub.usage.map(u => `<tr><td>${esc(u.metric)}</td><td>${Math.round(u.total)}</td></tr>`).join('') || '<tr><td colspan="2" style="color:var(--muted)">No usage yet</td></tr>'}
      </tbody></table></div>
    </div>
    <div class="card"><h3>Preferences</h3>
      <div class="row" style="justify-content:space-between;margin-bottom:14px"><div><b>Dark mode</b><div class="hint">Toggle theme</div></div>
        <div class="toggle ${state.theme === 'dark' ? 'on' : ''}" id="theme-toggle"></div></div>
      <div class="row" style="justify-content:space-between"><div><b>Clear all data</b><div class="hint">Reset this demo workspace</div></div>
        <button class="btn sm danger" id="reset">Reset</button></div>
    </div></div>`;
  $('#theme-toggle').onclick = () => { const th = state.theme === 'dark' ? 'light' : 'dark'; state.theme = th; document.documentElement.dataset.theme = th; localStorage.setItem('theme', th); render(); };
  $('#reset').onclick = () => { localStorage.clear(); location.reload(); };
}

// ---------------------------------------------------------------- init
function initRoute() {
  const h = location.hash.slice(1).split('/');
  const v = routes.includes(h[0]) ? h[0] : 'dashboard';
  state.route = { view: v, params: h[1] ? { id: h[1] } : {} };
}
window.addEventListener('hashchange', () => { initRoute(); render(); });
initRoute();
document.documentElement.dataset.theme = state.theme;
render();
