"""Clip analysis: finds meaningful moments in a transcript and scores them.

This is deliberately heuristic + NLP (no external API). It analyzes sentence
boundaries, topic shifts, questions, strong opinions, surprises, numbers,
emotional language and dead-air/pauses to generate candidate clips, then scores
each candidate across 10 virality/quality dimensions.

A production build can swap this for an LLM or multimodal model behind the same
ClipAnalysisProvider interface.
"""
import re, math

HOOK_WORDS = ["but", "actually", "wait", "watch", "listen", "here's", "here is",
              "this is", "the truth", "nobody", "everyone", "secret", "impossible",
              "insane", "crazy", "huge", "biggest", "best", "worst", "never",
              "always", "guaranteed", "warning", "dangerous", "mistake"]
OPINION_MODALS = ["should", "must", "have to", "has to", "need to", "can't", "cannot",
                  "refuse", "believe", "think", "personally", "honestly"]
SURPRISE = ["surprising", "shocked", "shocking", "unbelievable", "crazy", "insane",
            "wow", "wow,", "actually", "turns out", "turns out,", "it turns out",
            "believe it or not", "wouldn't believe", "no way", "that's wild"]
CONTROVERSIAL = ["controversial", "hot take", "unpopular opinion", "everyone's wrong",
                 "you're wrong", "against", "hate", "disagree", "attack", "stupid",
                 "worst take", "cancel", "debate"]
EMOTION = ["amazing", "terrible", "beautiful", "devastating", "furious", "in love",
           "heartbroken", "grateful", "excited", "terrified", "love", "hate",
           "angry", "happy", "sad", "incredible", "horrible"]
NUMBER = re.compile(r"\b(\d[\d,]*)\b")
Q_START = re.compile(r"^(what|why|how|when|where|who|which|do|does|did|is|are|was|were|can|could|will|would|should|have|has|did you|how do)\b", re.I)
LAUGH = re.compile(r"\b(haha|lol|lmao|huh|hmm|mhm|right|yeah right)\b", re.I)
STRONG_STOP = ["period", "period.", "that's it", "end of story", "done.", "exactly.",
               "no question", "without a doubt", "never again", "that's final"]
CTA_WORDS = ["subscribe", "follow", "link in bio", "comment", "share this",
             "tag someone", "watch the full"]


class Sentence:
    __slots__ = ("start", "end", "text", "words", "features")
    def __init__(self, start, end, text, words):
        self.start, self.end, self.text, self.words = start, end, text, words
        self.features = {}


def _words_from_segments(segments):
    words = []
    for s in segments:
        for w in s.get("words", []):
            t = re.sub(r"[^A-Za-z0-9'’.,?! ]", "", w["word"]).strip()
            if not t:
                continue
            words.append({"word": t, "start": w["start"], "end": w["end"]})
    words.sort(key=lambda x: x["start"])
    return words


def _split_sentences(words):
    """Group words into sentences at sentence-ending punctuation."""
    sentences, cur, cur_start = [], [], None
    for w in words:
        if cur_start is None:
            cur_start = w["start"]
        cur.append(w)
        if w["word"].endswith((".", "!", "?", "…", "...")):
            text = " ".join(x["word"] for x in cur)
            sentences.append(Sentence(cur_start, w["end"], text, cur))
            cur, cur_start = [], None
    if cur:
        text = " ".join(x["word"] for x in cur)
        sentences.append(Sentence(cur_start, cur[-1]["end"], text, cur))
    return sentences


def _sentence_features(s):
    t = s.text.lower()
    f = s.features
    f["question"] = 1 if s.text.endswith("?") or Q_START.match(t) else 0
    f["hook"] = sum(1 for w in HOOK_WORDS if w in t)
    f["opinion"] = sum(1 for w in OPINION_MODALS if w in t)
    f["surprise"] = sum(1 for w in SURPRISE if w in t)
    f["controversy"] = sum(1 for w in CONTROVERSIAL if w in t)
    f["emotion"] = sum(1 for w in EMOTION if w in t)
    f["numbers"] = len(NUMBER.findall(t))
    f["laugh"] = 1 if LAUGH.search(t) else 0
    f["strong_end"] = 1 if any(w in t for w in STRONG_STOP) else 0
    f["cta"] = sum(1 for w in CTA_WORDS if w in t)
    f["len_words"] = len(s.words)
    f["is_question"] = s.text.endswith("?")
    return f


def _topic_shift_penalty(s, prev):
    """Light topic shift detection via new rare content words."""
    if not prev:
        return 0
    stop = set("the a an and or but of to in on for with at by from as is are was were be been has have had this that these those it its i you we they he she them us it's you're i'm we're what who when where why how do does did not no yes so just really very much more most some all any can could will would should".split())
    def nouns(t):
        return set(w.strip("'’.,?!:;") for w in t.split()
                   if w.strip("'’.,?!:;") and w.strip("'’.,?!:;").lower() not in stop and len(w) > 3)
    a, b = nouns(prev.text), nouns(s.text)
    if not a or not b:
        return 0
    new_ratio = len(b - a) / len(b)
    return new_ratio


def find_moments(segments, min_dur, max_dur, focus=None, priority=None):
    """Returns list of candidate dicts with timestamps + per-dimension scores."""
    words = _words_from_segments(segments)
    sents = _split_sentences(words)
    for i, s in enumerate(sents):
        _sentence_features(s)
        if i > 0:
            s.features["topic_shift"] = _topic_shift_penalty(s, sents[i - 1])
        else:
            s.features["topic_shift"] = 0

    if not sents:
        return []

    # pause/dead-air per sentence: gap before this sentence
    for i, s in enumerate(sents):
        if i > 0:
            s.features["pre_gap"] = max(0.0, s.start - sents[i - 1].end)
        else:
            s.features["pre_gap"] = 0

    def hook_score(s):
        f = s.features
        v = (f["hook"] * 3.0 + f["surprise"] * 2.5 + f["controversy"] * 2.5 +
             f["question"] * 1.5 + f["opinion"] * 1.2 + f["emotion"] * 1.5 +
             f["numbers"] * 0.8 + f["laugh"] * 1.0 + f["topic_shift"] * 1.2)
        # penalize greetings/intros & dead air
        low = s.text.lower().strip()
        if re.match(r"^(hi|hello|hey|thanks|thank you|okay|ok|so um|um|alright|welcome back|welcome)", low):
            v -= 2.0
        if s.features["pre_gap"] > 2.5:
            v -= 1.5
        if focus:
            v += sum(3.0 for kw in focus if kw in low)
        if priority and any(pri in low for pri in priority):
            v += 4.0
        return v

    def payoff_score(s):
        f = s.features
        return (f["info_bonus"] * 0 + f["numbers"] * 1.5 + f["opinion"] * 1.5 +
                f["surprise"] * 1.5 + f["strong_end"] * 2.0 + f["question"] * 1.0 +
                f["cta"] * 1.5 + (1 if len(s.text) > 30 else 0) * 1.0)

    # tag information-dense sentences
    for s in sents:
        s.features["info_bonus"] = s.features["numbers"] + s.features["opinion"] * 0.7

    # Build candidate windows anchored on high-hook sentences.
    candidates = []
    anchors = sorted(range(len(sents)), key=lambda i: hook_score(sents[i]), reverse=True)
    used_ranges = []
    for ai in anchors:
        s = sents[ai]
        if hook_score(s) <= 0.5 and len(candidates) >= 3:
            continue
        # context: back up to include preceding sentence (topic grounding)
        ctx = ai
        if ai > 0 and (ai - 1).__class__ and True:
            prev = sents[ai - 1]
            if prev.features["pre_gap"] < 3.0:
                ctx = ai - 1
        start = sents[ctx].start
        # extend forward to target duration
        end = s.end
        cur = ai
        while cur + 1 < len(sents) and (end - start) < min_dur * 0.8:
            cur += 1
            end = sents[cur].end
        if (end - start) < 5:
            continue
        # enforce max duration: trim from front if needed
        if (end - start) > max_dur:
            # prefer dropping intro context, keep the punch
            while ctx + 1 < len(sents) and (end - sents[ctx].end) > max_dur:
                ctx += 1
                start = sents[ctx].start
            if (end - start) > max_dur:
                # trim end at sentence boundary
                while cur > ctx and (sents[cur].end - start) > max_dur:
                    cur -= 1
                end = sents[cur].end
        dur = end - start
        if dur < 4:
            continue
        # dedupe overlap
        if any(max(start, s2) < min(end, e2) - 1.0 for (s2, e2) in used_ranges):
            continue
        used_ranges.append((start, end))
        sents_in = [x for x in sents if x.end > start and x.start < end]
        full_text = " ".join(x.text for x in sents_in).strip()
        cand = {
            "start": round(start, 2), "end": round(end, 2),
            "duration": round(dur, 2),
            "text": full_text[:2000],
            "anchor_index": ai,
            "hook_snapshot": (s.text[:180] if s.text else "") + "…",
        }
        cand.update(score_candidate(cand, sents_in, hook_score, priority, focus))
        candidates.append(cand)
    return candidates


def score_candidate(cand, sents, hook_score, priority=None, focus=None):
    """10-dimension 0-100 scoring for a candidate clip."""
    n = len(sents)
    hook_s = hook_score(sents[0]) if sents else 0
    last = sents[-1] if sents else None

    def clamp(x):
        return max(0.0, min(100.0, x))

    hook_strength = clamp(min(100, hook_s * 12 + 26))
    curiosity = clamp(60 + (30 if sents[0].features["question"] else 0)
                      + (18 if sents[0].features["surprise"] else 0)
                      + (12 if sents[0].features["controversy"] else 0))
    emotional = clamp(sum(s.features["emotion"] for s in sents) * 10 +
                      sum(s.features["surprise"] for s in sents) * 9 +
                      sum(s.features["controversy"] for s in sents) * 9 + 26)
    entertainment = clamp(sum(s.features["laugh"] for s in sents) * 16 +
                          sum(s.features["surprise"] for s in sents) * 9 +
                          hook_strength * 0.3 + 24)
    info = clamp(sum(s.features["numbers"] for s in sents) * 11 +
                 sum(s.features["opinion"] for s in sents) * 7 + 26)
    # stand-alone: enough context at start + full idea contained
    standalone = clamp(70 + (8 if len(sents) >= 2 else 0) -
                       (22 if sents[0].features["pre_gap"] > 2 else 0) +
                       (12 if last and last.features["strong_end"] else 0))
    # pacing: penalize dead air, reward variation
    gaps = [s.features["pre_gap"] for s in sents]
    dead_air = sum(1 for g in gaps if g > 1.5)
    pacing = clamp(74 - dead_air * 9 + min(18, cand["duration"] * 0.4))
    shareable = clamp(hook_strength * 0.4 + entertainment * 0.4 +
                      (15 if last and last.features["cta"] else 0) + 12)
    # originality: topic shifts + rare viewpoints
    originality = clamp(sum(s.features["topic_shift"] for s in sents) * 16 +
                        sum(s.features["controversy"] for s in sents) * 9 + 26)
    ending = clamp((last.features["strong_end"] if last else 0) * 40 +
                   (20 if last and last.features["question"] else 0) +
                   (15 if last and last.features["cta"] else 0) +
                   min(30, sum(s.features["info_bonus"] for s in sents) * 4) + 18)

    if priority and any(pri in " ".join(s.text.lower() for s in sents)
                        for pri in priority):
        overall_bonus = 8
    elif priority:
        overall_bonus = -6
    else:
        overall_bonus = 0

    overall = (hook_strength * 0.20 + curiosity * 0.08 + emotional * 0.10 +
               entertainment * 0.15 + info * 0.12 + standalone * 0.10 +
               pacing * 0.08 + shareable * 0.08 + originality * 0.04 +
               ending * 0.05) + overall_bonus
    # calibration: a well-formed clip (context+hook+payoff+ending) deserves high marks
    overall = clamp(overall * 1.04 + 6)

    label = ("Excellent" if overall >= 85 else "Strong" if overall >= 75 else
             "Good" if overall >= 65 else "Fair" if overall >= 50 else "Weak")
    return {
        "scores": {"hook_strength": round(hook_strength),
                   "curiosity": round(curiosity),
                   "emotional_intensity": round(emotional),
                   "entertainment": round(entertainment),
                   "information": round(info),
                   "standalone_context": round(standalone),
                   "pacing": round(pacing),
                   "shareability": round(shareable),
                   "originality": round(originality),
                   "ending_quality": round(ending),
                   "overall": round(overall)},
        "score": round(overall), "score_label": label,
        "reason": _reason_text(cand, scores_hook=hook_strength, info=info,
                               entertainment=entertainment, overall=overall),
    }


def _reason_text(cand, scores_hook, info, entertainment, overall):
    parts = []
    if scores_hook >= 75:
        parts.append("opens with a strong hook")
    elif scores_hook >= 55:
        parts.append("decent opening hook")
    else:
        parts.append("gentle opening")
    if info >= 70:
        parts.append("high information value")
    if entertainment >= 70:
        parts.append("entertaining")
    if overall >= 80:
        parts.append("exceptionally strong candidate")
    if cand["duration"] > 40:
        parts.append(f"{cand['duration']:.0f}s runtime")
    return ", ".join(parts)
