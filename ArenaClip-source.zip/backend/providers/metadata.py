"""Metadata generation for each target platform, based on the actual clip text.

Never returns generic placeholders. Keywords are extracted from the transcript
and woven into natural titles/descriptions/hashtags per platform.
"""
import re

STOP = set("""the a an and or but of to in on for with at by from as is are was
were be been has have had this that these those it its i you we they he she them
us it's you're i'm we're we've don't can't isn't was' n't not no yes so just
really very much more most some all any can could will would should about into
over under again then once here there when where why how do does did people
thing things way today show going know think get got make take say said want
need one two three time thing everything something anything nothing really
actually let's gonna guess good bad great nice love big small money really
everyone nobody secret means mean stuff
your my his her their our me him them mine yours hers ours their""".split())

HASHTAG_SEEDS = ["shorts", "viral", "reels", "fyp", "podcast", "interview",
                 "motivation", "advice", "tips", "trending", "learnontiktok",
                 "for you", "fy", "insights"]


GENERIC = {"interesting", "amazing", "great", "really", "people", "thing", "things",
           "today", "way", "show", "going", "know", "think", "get", "got", "make",
           "take", "like", "said", "wants", "doesn", "doesn't", "didn", "didn't",
           "you're", "let's", "gonna", "wanna", "actually", "just", "even", "still",
           "also", "would", "could", "should", "everyone", "nobody", "somebody",
           "always", "never", "sometimes", "maybe", "things", "everything",
           "something", "anything", "says", "okay", "right", "yeah", "sort", "kind"}


def extract_keywords(text, top=8):
    toks = re.findall(r"[A-Za-z'’][A-Za-z'’0-9\-]{3,}", text.lower())
    from collections import Counter
    c = Counter()
    for i, t in enumerate(toks):
        t = re.sub(r"['’]s$", "", t)  # strip possessive only, keep real "s"
        if t in STOP or t in GENERIC or len(t) < 3 or re.fullmatch(r"\d+", t):
            continue
        c[t] += 1
        if i + 1 < len(toks):
            b = re.sub(r"['’]s$", "", toks[i + 1])
            if b not in STOP and b not in GENERIC and t not in STOP and t not in GENERIC:
                c[f"{t} {b}"] += 0.6
    candidates = [k for k in c if not re.fullmatch(r"\d+", k)]
    def score(k):
        n = k.count(" ") + 1            # bigrams/phrases rank higher
        return (1 if n == 2 else 0) * 30 + min(c[k], 12) + (2 if len(k) > 8 else 0)
    ranked = sorted(candidates, key=lambda k: (-score(k), -c[k]))
    return ranked[:top]


def _topic_noun(text):
    toks = re.findall(r"[A-Z][a-z]+", text) or re.findall(r"[A-Za-z'’]{5,}", text)
    seen = []
    for t in toks:
        if t.lower() not in STOP and t.lower() not in [s.lower() for s in seen]:
            seen.append(t)
        if len(seen) >= 4:
            break
    return seen


def generate_metadata(clip_text, platform, brand=None, focus=None):
    text = (clip_text or "").strip()
    kws = extract_keywords(text, top=6)
    topic = kws[0].title() if kws else ("This story" if len(text) > 40 else "This clip")
    hook = _first_hook(text)
    ctx = _context(text)

    # ---- titles per platform
    if platform == "youtube_shorts":
        title = _title(text, kws, hook, max_len=70)
    elif platform == "tiktok":
        title = _title(text, kws, hook, max_len=60)
    else:  # instagram_reels
        title = _title(text, kws, hook, max_len=50)

    # ---- hashtags
    hashtags = _hashtags(text, kws, platform)

    # ---- description / caption
    description = _description(text, ctx, topic, platform, kws)

    # ---- CTA
    cta = _cta(platform, brand, focus)

    # ---- seo keywords
    keywords = kws[:5] if kws else []

    return {"title": title, "description": description, "hashtags": hashtags,
            "cta": cta, "keywords": keywords}


def _first_hook(text):
    parts = [p for p in re.split(r"(?<=[.!?])\s+", text) if p.strip()]
    if not parts:
        return text[:80]
    first = parts[0].strip()
    return first[:90] if first else text[:90]


def _context(text):
    parts = [p for p in re.split(r"(?<=[.!?])\s+", text) if p.strip()]
    if len(parts) > 1:
        return " ".join(parts[:3])[:240]
    return text[:240]


def _title(text, kws, hook, max_len):
    hook = re.sub(r"[\"']", "", hook).strip(" .")
    kw = kws[0].title() if kws else None
    cands = []
    if kw:
        cands.append(f"{hook} — {kw}")
        cands.append(f"{kw}: {hook}")
    cands.append(hook)
    cands.append(f"{hook} — Watch This")
    for c in cands:
        if c and len(c) <= max_len:
            return c
    return hook[:max_len]


def _hashtags(text, kws, platform):
    tags = set()
    platform_tags = {
        "youtube_shorts": ["#Shorts", "#YouTubeShorts"],
        "tiktok": ["#fyp", "#foryou", "#TikTok"],
        "instagram_reels": ["#Reels", "#reelsinstagram"],
    }
    tags.update(platform_tags.get(platform, ["#Shorts"]))
    for k in kws[:4]:
        tag = "#" + "".join(w.capitalize() for w in k.split())[:24]
        tags.add(tag)
    for s in HASHTAG_SEEDS[:3]:
        tags.add("#" + s.replace(" ", "").capitalize())
    return " ".join(sorted(tags, key=len, reverse=True)[:12])


def _description(text, ctx, topic, platform, kws):
    kw = kws[0].title() if kws else topic
    if platform == "youtube_shorts":
        d = (f"{ctx}\n\n{kw} — the takeaway you didn't see coming. "
             f"Save this for later. #Shorts")
    elif platform == "tiktok":
        d = f"{ctx}\n\nPOV: this clip is too good not to share 👀 #fyp"
    else:
        d = f"{ctx}\n\nThis moment from the full conversation was too good to skip."
    return d


def _cta(platform, brand, focus):
    default = {
        "youtube_shorts": "Watch the full video on our channel.",
        "tiktok": "Follow for more clips like this.",
        "instagram_reels": "Follow for more — full video on our page.",
    }
    if brand and brand.get("default_cta"):
        return brand["default_cta"]
    return default.get(platform, default["youtube_shorts"])
