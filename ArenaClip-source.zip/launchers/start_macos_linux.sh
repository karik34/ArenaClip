#!/usr/bin/env bash
# ArenaClip one-click launcher for macOS & Linux.
# Usage:  bash start_macos_linux.sh      (or ./start_macos_linux.sh)
set -e
cd "$(dirname "$0")"

echo
echo "============================================================"
echo "  ArenaClip  -  AI Video Repurposing Studio"
echo "============================================================"
echo

# 1. Python
if ! command -v python3 >/dev/null 2>&1; then
  echo "[!] Python 3 is required. Install it from https://www.python.org/downloads/"
  exit 1
fi

# 2. FFmpeg
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "[!] FFmpeg not found."
  echo "    macOS:  brew install ffmpeg"
  echo "    Linux:  sudo apt install ffmpeg   (or your distro's package manager)"
  exit 1
fi

# 3. venv + deps
if [ ! -d ".venv" ]; then
  echo "[1/3] Creating a private Python environment..."
  python3 -m venv .venv
fi
source .venv/bin/activate
echo "[2/3] Installing/updating dependencies..."
python -m pip install --upgrade pip -q
pip install -r requirements.txt -q

# 4. Launch
echo "[3/3] Starting ArenaClip..."
echo
echo "------------------------------------------------------------"
echo "  Opening your browser at  http://127.0.0.1:8000"
echo "  Press Ctrl+C in this window to stop the server."
echo "------------------------------------------------------------"
echo
( sleep 2; xdg-open http://127.0.0.1:8000 2>/dev/null || open http://127.0.0.1:8000 2>/dev/null ) &
export PYTHONPATH="$PWD"
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
