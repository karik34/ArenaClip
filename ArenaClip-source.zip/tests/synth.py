"""Synthesize a realistic spoken podcast video for end-to-end pipeline testing."""
import subprocess, os, sys, textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

SCRIPT = [
    ("Welcome back to the show. Today we have a really interesting guest and I promise this is going to change how you think about money.",
     0.4),
    ("Here's the thing nobody tells you about saving. Everyone talks about cutting your coffee, but that is not how you build wealth.",
     0.5),
    ("The real secret is automation. You set up your bank to move money the second your paycheck hits. Do not give yourself a choice.",
     0.6),
    ("When I started investing, my biggest mistake was trying to time the market. I lost thousands. I can't believe how naive I was.",
     0.5),
    ("But actually, the data shows that most people who panic sell during a crash regret it within a year. It's wild how predictable it is.",
     0.4),
    ("Here's a controversial opinion. You should not follow generic financial advice. Most of it was written for people who are not you.",
     0.5),
    ("The best investors I know are boring. They do the same thing every single month for decades. And that consistency is what creates millions.",
     0.4),
    ("So what would you tell a twenty year old starting today? The answer is simple. Start now, automate it, and never stop. That's it.",
     0.5),
    ("Thank you so much for listening. Subscribe and follow for more, and I'll see you in the next episode.",
     0.3),
]


def synth_audio(out_wav, rate=165):
    chunks = []
    for text, gap in SCRIPT:
        w = f"/tmp/piece_{len(chunks)}.wav"
        subprocess.run(["espeak-ng", "-w", w, "-s", str(rate),
                        "-v", "en-us+m3", text], capture_output=True)
        chunks.append(w)
        # add silence gap file
        g = f"/tmp/gap_{len(chunks)}.wav"
        subprocess.run(["ffmpeg", "-y", "-f", "lavfi",
                        "-i", f"anullsrc=r=22050:cl=mono:d={gap}", "-q:a", "9", g],
                       capture_output=True)
        chunks.append(g)
    concat_list = "/tmp/chunks.txt"
    Path(concat_list).write_text("\n".join(f"file '{c}'" for c in chunks))
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_list,
                    "-c:a", "pcm_s16le", out_wav], capture_output=True)
    return out_wav


def make_video(audio, out_mp4, w=1920, h=1080, duration=None):
    args = ["ffmpeg", "-y", "-i", audio,
            "-f", "lavfi", "-i", f"color=c=0x14141f:s={w}x{h}:d={duration or 60}",
            "-vf", f"drawtext=text='Test Podcast':fontcolor=white:fontsize=80:x=(w-text_w)/2:y=(h-text_h)/2,format=yuv420p",
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-shortest", out_mp4]
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stderr[-600:])
        raise SystemExit("video synth failed")
    return out_mp4


if __name__ == "__main__":
    audio = synth_audio("/tmp/test_audio.wav")
    make_video(audio, "/tmp/test_video.mp4")
    from backend.providers.ingestion import probe_video
    print("probe:", probe_video("/tmp/test_video.mp4"))
