import requests, time, json, sys
BASE = "http://127.0.0.1:8000"
email = f"test{int(time.time())}@example.com"

print("1. health:", requests.get(BASE+"/api/health").json())
r = requests.post(BASE+"/api/auth/register", json={"email": email, "password": "secret123", "name": "Test User"})
print("2. register:", r.status_code)
tok = r.json()["token"]
H = {"Authorization": "Bearer "+tok}

cfg = {"num_clips": 3, "min_duration": 12, "max_duration": 30,
       "platforms": ["youtube_shorts","tiktok","instagram_reels"],
       "caption_style": "dynamic", "editing_intensity": "high", "music": "energetic",
       "min_score": 40, "approval": "automatic", "publishing": "manual",
       "focus": ["Funny","Surprising"], "style": "fast", "music_volume": 0.16,
       "schedule": {"interval_days": 1, "time": "18:00"}}
r = requests.post(BASE+"/api/projects", json={"name":"E2E Podcast","config":cfg}, headers=H)
pid = r.json()["id"]
print("3. project:", pid, r.status_code)

with open("/tmp/test_video.mp4","rb") as f:
    r = requests.post(BASE+f"/api/projects/{pid}/ingest/upload",
                      files={"file":("test_video.mp4", f, "video/mp4")}, headers=H)
print("4. upload:", r.status_code, r.json())

# poll until project ready
print("5. polling pipeline...")
start = time.time()
while time.time() - start < 300:
    clips = requests.get(BASE+f"/api/projects/{pid}/clips", headers=H).json()
    done = [c for c in clips if c["status"] in ("ready","scheduled","published","needs_review","failed")]
    if len(done) == len(clips) and len(clips) > 0:
        proj = requests.get(BASE+f"/api/projects/{pid}", headers=H).json()
        print(f"   project status={proj['status']} clips={len(clips)} t={time.time()-start:.0f}s")
        break
    time.sleep(4)
else:
    print("   TIMEOUT waiting for pipeline")

clips = requests.get(BASE+f"/api/projects/{pid}/clips", headers=H).json()
print(f"6. got {len(clips)} clips:")
for c in clips:
    print(f"   [{c['score']}/100] {c['status']:12s} {c['start_ts']:.1f}-{c['end_ts']:.1f}s  url={'yes' if c.get('video_url') else 'NO'}")
    mds = c.get("metadata") or []
    for m in mds[:1]:
        print(f"      title: {m['title'][:60]}")

# fetch a ready clip and its media
ready = [c for c in clips if c.get("video_url")]
if ready:
    c = ready[0]
    print("7. media url:", c["video_url"][:70])
    mr = requests.get(BASE+c["video_url"])
    print("   media fetch status:", mr.status_code, "bytes:", len(mr.content), "type:", mr.headers.get("content-type"))
    # download
    dr = requests.get(BASE+f"/api/clips/{c['id']}/download", headers=H)
    print("   download:", dr.status_code, len(dr.content), "bytes")
    # schedule to calendar
    qr = requests.post(BASE+f"/api/clips/{c['id']}/queue", headers=H,
                       json={"platform":"youtube_shorts","scheduled_at":"2026-08-19T18:00:00"})
    print("   queue:", qr.status_code, qr.json().get("status"))
    cal = requests.get(BASE+"/api/calendar", headers=H).json()
    print("   calendar jobs:", len(cal))
    # accounts + brandkit + autopilot smoke
    print("8. accounts:", requests.get(BASE+"/api/accounts", headers=H).status_code)
    print("9. brandkit put:", requests.put(BASE+"/api/brandkit", headers=H, json={"name":"My Brand","config":{"default_cta":"Follow for more."}}).status_code)
    a = requests.post(BASE+"/api/automations", headers=H, json={"name":"Auto","source_url":"https://youtube.com/@x","config":cfg}).json()
    print("10. automation:", a.get("id"))
print("E2E OK")
