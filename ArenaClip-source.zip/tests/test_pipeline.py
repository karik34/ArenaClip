import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend import db
from backend.providers.transcription import TranscriptionProvider
from backend.providers import analysis as anl
from backend.providers import broll, metadata as meta

db.init_db()

VIDEO = "/tmp/test_video.mp4"
t0 = time.time()
print("Transcribing...")
tp = TranscriptionProvider()
res = tp.transcribe(VIDEO)
print(f"  lang={res['language']} dur={res['duration']:.1f}s words={sum(len(s['words']) for s in res['segments'])} in {time.time()-t0:.1f}s")
print("  text head:", res["text"][:120])

print("\nFinding moments...")
cands = anl.find_moments(res["segments"], min_dur=12, max_dur=30)
cands.sort(key=lambda c: c["score"], reverse=True)
print(f"  {len(cands)} candidates")
for c in cands[:6]:
    print(f"  [{c['start']:.1f}-{c['end']:.1f}] {c['score']}/100 {c['score_label']:10s} hook: {c['hook_snapshot'][:45]}")

print("\nMetadata sample (youtube_shorts):")
c = cands[0]
md = meta.generate_metadata(c["text"], "youtube_shorts")
print("  TITLE:", md["title"])
print("  CTA:", md["cta"])
print("  TAGS:", md["hashtags"][:100])

print("\nMusic gen...")
broll.ensure_music_library()
print("  music:", sorted((Path('storage/music').glob('*.wav'))))

db.emit("test", "clip", "x", {"msg": "hello"})
print("\nPipeline test OK")
