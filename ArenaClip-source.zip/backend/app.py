"""ArenaClip API — FastAPI application.

Auth -> projects -> ingestion -> transcription -> analysis -> rendering ->
metadata -> scheduling -> publishing. Serves the SPA frontend.
"""
import os, json, shutil, tempfile
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import (FileResponse, StreamingResponse, JSONResponse,
                               HTMLResponse)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr
from typing import Optional, List

from . import db, jobs, auth
from .config import (BASE_DIR, STORAGE_DIR, MAX_UPLOAD_BYTES, PUBLIC_BASE,
                     DEFAULT_CREDITS)
from . import pipeline
from .storage import signed_url, verify_signature, safe_media_path, ensure_buckets
from .providers import broll, metadata as meta
from .providers.publishing import PROVIDERS, connect_account

FRONTEND_DIR = BASE_DIR / "frontend"


# ------------------------------------------------------------------ lifespan
@asynccontextmanager
async def lifespan(app):
    db.init_db()
    ensure_buckets()
    jobs.start_workers(n=2)
    from .providers.publishing import start_scheduler
    start_scheduler()
    yield


app = FastAPI(title="ArenaClip API", version="0.1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"])


# ------------------------------------------------------------------ schemas
class RegisterIn(BaseModel):
    email: EmailStr
    password: str
    name: str = ""


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ProjectIn(BaseModel):
    name: str
    config: dict = {}
    source_url: Optional[str] = None


class IngestUrlIn(BaseModel):
    url: str


class QueueIn(BaseModel):
    platform: str
    account_id: Optional[str] = None
    scheduled_at: Optional[str] = None


class MetadataEdit(BaseModel):
    platform: str
    title: Optional[str] = None
    description: Optional[str] = None
    hashtags: Optional[str] = None
    cta: Optional[str] = None


class ClipEdit(BaseModel):
    start_ts: Optional[float] = None
    end_ts: Optional[float] = None
    caption_style: Optional[str] = None
    music_style: Optional[str] = None
    music_volume: Optional[float] = None
    editing_intensity: Optional[str] = None


class ConnectIn(BaseModel):
    platform: str
    display_name: str = ""
    handle: str = ""
    token: str = "demo"


class AutomationIn(BaseModel):
    name: str
    source_url: str
    config: dict = {}


class BrandKitIn(BaseModel):
    name: str = "My Brand"
    config: dict = {}


# ------------------------------------------------------------------ auth
@app.post("/api/auth/register")
def register(body: RegisterIn):
    if len(body.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    existing = db.query("SELECT * FROM users WHERE email=?", (body.email.lower(),))
    if existing:
        raise HTTPException(409, "An account with this email already exists.")
    uid = db.new_id()
    db.insert("users", {"id": uid, "email": body.email.lower(),
                        "password_hash": auth.hash_password(body.password),
                        "name": body.name or body.email.split("@")[0],
                        "plan": "free", "created_at": db.now()})
    db.insert("subscriptions", {"id": db.new_id(), "user_id": uid, "plan": "free",
                                "credits_remaining": DEFAULT_CREDITS,
                                "credits_used": 0, "status": "active",
                                "created_at": db.now()})
    return {"token": auth.create_token(uid), "user": _user(uid)}


@app.post("/api/auth/login")
def login(body: LoginIn):
    u = db.get_one("SELECT * FROM users WHERE email=?", (body.email.lower(),))
    if not u or not auth.verify_password(body.password, u["password_hash"]):
        raise HTTPException(401, "Incorrect email or password.")
    return {"token": auth.create_token(u["id"]), "user": _user(u["id"])}


@app.get("/api/auth/me")
def me(user: dict = Depends(auth.get_current_user)):
    return user


def _user(uid):
    u = db.get_one("SELECT * FROM users WHERE id=?", (uid,))
    u.pop("password_hash", None)
    sub = db.get_one("SELECT * FROM subscriptions WHERE user_id=?", (uid,))
    u["subscription"] = sub
    return u


# ------------------------------------------------------------------ dashboard
@app.get("/api/dashboard")
def dashboard(user: dict = Depends(auth.get_current_user)):
    uid = user["id"]
    projects = db.query("SELECT * FROM projects WHERE user_id=? ORDER BY created_at DESC",
                        (uid,))
    out = []
    for p in projects:
        clips = db.query("SELECT status FROM clips WHERE project_id=?", (p["id"],))
        counts = {}
        for c in clips:
            counts[c["status"]] = counts.get(c["status"], 0) + 1
        out.append({"id": p["id"], "name": p["name"], "status": p["status"],
                    "source_url": p["source_url"],
                    "clips": len(clips), "counts": counts,
                    "created_at": p["created_at"]})
    agg = db.get_one("SELECT COUNT(*) c, AVG(score) a FROM clips WHERE user_id=? AND score IS NOT NULL",
                     (uid,))
    sub = db.get_one("SELECT * FROM subscriptions WHERE user_id=?", (uid,))
    return {"projects": out,
            "stats": {
                "total_clips": db.get_one("SELECT COUNT(*) c FROM clips WHERE user_id=?", (uid,))["c"],
                "published": db.get_one("SELECT COUNT(*) c FROM clips WHERE user_id=? AND status='published'", (uid,))["c"],
                "scheduled": db.get_one("SELECT COUNT(*) c FROM publishing_jobs WHERE user_id=? AND status IN ('scheduled','queued')", (uid,))["c"],
                "processing": db.get_one("SELECT COUNT(*) c FROM clips WHERE user_id=? AND status IN ('processing','queued')", (uid,))["c"],
                "avg_score": round((agg["a"] or 0), 1) if agg["c"] else None,
            },
            "credits_remaining": sub["credits_remaining"] if sub else 0}


# ------------------------------------------------------------------ projects
@app.post("/api/projects")
def create_project(body: ProjectIn, user: dict = Depends(auth.get_current_user)):
    if not body.name.strip():
        raise HTTPException(400, "Project needs a name.")
    _validate_config(body.config)
    pid = pipeline.create_project(user["id"], body.name.strip(), body.config,
                                  body.source_url)
    p = db.get_one("SELECT * FROM projects WHERE id=?", (pid,))
    p["config"] = json.loads(p["config_json"] or "{}")
    return p


def _validate_config(cfg):
    if cfg.get("min_duration") and cfg.get("max_duration"):
        if cfg["min_duration"] >= cfg["max_duration"]:
            raise HTTPException(400, "min_duration must be less than max_duration")
    if cfg.get("num_clips") and not (1 <= cfg["num_clips"] <= 30):
        raise HTTPException(400, "num_clips must be between 1 and 30")


@app.get("/api/projects")
def list_projects(user: dict = Depends(auth.get_current_user)):
    rows = db.query("SELECT * FROM projects WHERE user_id=? ORDER BY created_at DESC",
                    (user["id"],))
    for p in rows:
        p["config"] = json.loads(p["config_json"] or "{}")
    return rows


@app.get("/api/projects/{pid}")
def project_detail(pid: str, user: dict = Depends(auth.get_current_user)):
    p = auth.require_owner("projects", pid, user["id"])
    p["config"] = json.loads(p["config_json"] or "{}")
    p["source_video"] = db.get_one("SELECT * FROM source_videos WHERE project_id=? LIMIT 1", (pid,))
    tr = db.query("SELECT * FROM transcripts WHERE source_video_id=? ORDER BY created_at DESC LIMIT 1",
                  (p["source_video"]["id"],)) if p["source_video"] else []
    p["transcript"] = tr[0] if tr else None
    return p


@app.get("/api/projects/{pid}/events")
async def project_events(pid: str, request: Request,
                         user: dict = Depends(auth.get_current_user)):
    auth.require_owner("projects", pid, user["id"])
    return StreamingResponse(jobs.sse_stream(scope="project", entity="project",
                                             entity_id=pid, replay=True),
                             media_type="text/event-stream")


@app.get("/api/projects/{pid}/clips")
def project_clips(pid: str, user: dict = Depends(auth.get_current_user)):
    auth.require_owner("projects", pid, user["id"])
    clips = db.query("SELECT * FROM clips WHERE project_id=? ORDER BY position", (pid,))
    out = []
    for c in clips:
        out.append(_clip_view(c))
    return out


def _clip_view(c):
    scores = db.get_one("SELECT * FROM clip_scores WHERE clip_id=?", (c["id"],))
    metas = db.query("SELECT * FROM clip_metadata WHERE clip_id=?", (c["id"],))
    view = dict(c)
    view.pop("project_id", None)
    view["scores"] = scores
    view["metadata"] = metas
    if c.get("video_path"):
        view["video_url"] = signed_url(c["video_path"])
    if c.get("thumbnail_path"):
        view["thumbnail_url"] = signed_url(c["thumbnail_path"])
    return view


# ------------------------------------------------------------------ ingest
@app.post("/api/projects/{pid}/ingest/url")
def ingest_url(pid: str, body: IngestUrlIn,
               user: dict = Depends(auth.get_current_user)):
    auth.require_owner("projects", pid, user["id"])
    try:
        ing.validate_url(body.url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    pipeline.start_ingest_url(pid, body.url.strip())
    return {"ok": True, "message": "Processing started"}


@app.post("/api/projects/{pid}/ingest/upload")
async def ingest_upload(pid: str, file: UploadFile = File(...),
                        user: dict = Depends(auth.get_current_user)):
    auth.require_owner("projects", pid, user["id"])
    try:
        from .providers.ingestion import validate_upload
        validate_upload(file.filename or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    tmp_dir = Path(STORAGE_DIR) / "temp" / "uploads"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_path = tmp_dir / f"{db.new_id()}{Path(file.filename).suffix}"
    size = 0
    with open(tmp_path, "wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                tmp_path.unlink(missing_ok=True)
                raise HTTPException(413, "File exceeds the upload limit (2 GB).")
            out.write(chunk)
    pipeline.start_ingest_upload(pid, str(tmp_path), file.filename)
    return {"ok": True, "message": "Upload received, processing started"}


# ------------------------------------------------------------------ clips
@app.get("/api/clips/{cid}")
def clip_detail(cid: str, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    return _clip_view(c)


@app.patch("/api/clips/{cid}")
def edit_clip(cid: str, body: ClipEdit, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    upd = {}
    if body.start_ts is not None:
        upd["start_ts"] = body.start_ts
    if body.end_ts is not None:
        upd["end_ts"] = body.end_ts
    if upd.get("end_ts") and upd.get("start_ts") and upd["end_ts"] <= upd["start_ts"]:
        raise HTTPException(400, "end must be after start")
    # style changes require re-render
    if body.caption_style:
        db.update("clips", {"caption_style": body.caption_style}, "id=?", (cid,))
    if body.editing_intensity:
        db.update("clips", {"editing_intensity": body.editing_intensity}, "id=?", (cid,))
    if upd:
        db.update("clips", upd, "id=?", (cid,))
        dur = (upd.get("end_ts") or c["end_ts"]) - (upd.get("start_ts") or c["start_ts"])
        db.update("clips", {"duration": round(dur, 2)}, "id=?", (cid,))
    return _clip_view(db.get_one("SELECT * FROM clips WHERE id=?", (cid,)))


@app.post("/api/clips/{cid}/render")
def rerender_clip(cid: str, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    # persist current style choices onto the clip so renderer picks them up
    db.update("clips", {"status": "processing"}, "id=?", (cid,))
    jobs.enqueue("render_clip", cid, pipeline._render_clip_job,
                 table="render_jobs", id=db.new_id(), clip_id=cid,
                 project_id=c["project_id"])
    return {"ok": True, "message": "Re-rendering clip"}


@app.post("/api/clips/{cid}/metadata/regenerate")
def regen_metadata(cid: str, body: dict = None, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    project = db.get_one("SELECT * FROM projects WHERE id=?", (c["project_id"],))
    config = json.loads(project["config_json"] or "{}")
    platforms = config.get("platforms") or ["youtube_shorts"]
    for plat in platforms:
        md = meta.generate_metadata(c["transcript"] or "", plat, focus=config.get("focus"))
        existing = db.query("SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?",
                            (cid, plat))
        row = {"title": md["title"], "description": md["description"],
               "hashtags": md["hashtags"], "cta": md["cta"],
               "keywords": ",".join(md["keywords"]), "status": "generated"}
        if existing:
            db.update("clip_metadata", row, "id=?", (existing[0]["id"],))
        else:
            row.update({"id": db.new_id(), "clip_id": cid, "platform": plat,
                        "created_at": db.now()})
            db.insert("clip_metadata", row)
    return {"ok": True, "message": "Metadata regenerated"}


@app.patch("/api/clips/{cid}/metadata")
def edit_metadata(cid: str, body: MetadataEdit, user: dict = Depends(auth.get_current_user)):
    auth.require_owner("clips", cid, user["id"])
    row = db.get_one("SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?",
                     (cid, body.platform))
    if not row:
        raise HTTPException(404, "No metadata for that platform")
    upd = {"status": "edited"}
    for k in ("title", "description", "hashtags", "cta"):
        v = getattr(body, k, None)
        if v is not None:
            upd[k] = v
    db.update("clip_metadata", upd, "id=?", (row["id"],))
    return db.get_one("SELECT * FROM clip_metadata WHERE id=?", (row["id"],))


@app.post("/api/clips/{cid}/queue")
def queue_clip(cid: str, body: QueueIn, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    from .providers.publishing import SUPPORTED_PLATFORMS
    if body.platform not in SUPPORTED_PLATFORMS:
        raise HTTPException(400, "Unsupported platform. Use youtube_shorts, tiktok or instagram_reels.")
    pj = pipeline.queue_publish(cid, user["id"], body.platform, body.account_id,
                                body.scheduled_at)
    return {"ok": True, "id": pj, "message": "Scheduled"}


@app.get("/api/clips/{cid}/download")
def download_clip(cid: str, user: dict = Depends(auth.get_current_user)):
    c = auth.require_owner("clips", cid, user["id"])
    p = safe_media_path(c["video_path"])
    if not p:
        raise HTTPException(404, "Rendered video not found. Render the clip first.")
    return FileResponse(p, media_type="video/mp4",
                        filename=f"clip_{cid[:8]}.mp4")


# ------------------------------------------------------------------ calendar
@app.get("/api/calendar")
def calendar(user: dict = Depends(auth.get_current_user)):
    jobs = db.query("""SELECT pj.*, c.project_id, c.thumbnail_path, c.video_path, c.duration
                       FROM publishing_jobs pj JOIN clips c ON c.id=pj.clip_id
                       WHERE pj.user_id=? ORDER BY pj.scheduled_at""", (user["id"],))
    for j in jobs:
        j["title"] = ""
        md = db.get_one("SELECT title FROM clip_metadata WHERE clip_id=? AND platform=?",
                        (j["clip_id"], j["platform"]))
        if md:
            j["title"] = md["title"]
        if j.get("thumbnail_path"):
            j["thumb_url"] = signed_url(j["thumbnail_path"])
    return jobs


@app.patch("/api/publishing/{pjid}")
def reschedule(pjid: str, body: dict, user: dict = Depends(auth.get_current_user)):
    pj = db.get_one("SELECT * FROM publishing_jobs WHERE id=?", (pjid,))
    if not pj or pj["user_id"] != user["id"]:
        raise HTTPException(404, "Not found")
    if body.get("scheduled_at"):
        db.update("publishing_jobs", {"scheduled_at": body["scheduled_at"],
                                      "status": "scheduled"}, "id=?", (pjid,))
        db.update("clips", {"status": "scheduled"}, "id=?", (pj["clip_id"],))
    return db.get_one("SELECT * FROM publishing_jobs WHERE id=?", (pjid,))


# ------------------------------------------------------------------ accounts
@app.get("/api/accounts")
def accounts(user: dict = Depends(auth.get_current_user)):
    rows = db.query("SELECT * FROM social_accounts WHERE user_id=?", (user["id"],))
    for r in rows:
        r.pop("token_enc", None)
    return rows


@app.post("/api/accounts")
def add_account(body: ConnectIn, user: dict = Depends(auth.get_current_user)):
    acc_id = connect_account(user["id"], body.platform, body.display_name,
                             body.handle, body.token)
    return db.get_one("SELECT * FROM social_accounts WHERE id=?", (acc_id,))


@app.delete("/api/accounts/{aid}")
def disconnect_account(aid: str, user: dict = Depends(auth.get_current_user)):
    row = db.get_one("SELECT * FROM social_accounts WHERE id=? AND user_id=?", (aid, user["id"]))
    if not row:
        raise HTTPException(404, "Not found")
    db.execute("DELETE FROM social_accounts WHERE id=?", (aid,))
    return {"ok": True}


# ------------------------------------------------------------------ autopilot
@app.get("/api/automations")
def automations(user: dict = Depends(auth.get_current_user)):
    rows = db.query("SELECT * FROM automations WHERE user_id=?", (user["id"],))
    for r in rows:
        r["config"] = json.loads(r["config_json"] or "{}")
    return rows


@app.post("/api/automations")
def create_automation(body: AutomationIn, user: dict = Depends(auth.get_current_user)):
    aid = db.new_id()
    db.insert("automations", {"id": aid, "user_id": user["id"], "name": body.name,
                              "source_url": body.source_url,
                              "config_json": json.dumps(body.config), "enabled": 0,
                              "created_at": db.now()})
    return db.get_one("SELECT * FROM automations WHERE id=?", (aid,))


@app.patch("/api/automations/{aid}")
def toggle_automation(aid: str, body: dict, user: dict = Depends(auth.get_current_user)):
    row = db.get_one("SELECT * FROM automations WHERE id=? AND user_id=?", (aid, user["id"]))
    if not row:
        raise HTTPException(404, "Not found")
    enabled = body.get("enabled", row["enabled"])
    db.update("automations", {"enabled": int(bool(enabled))}, "id=?", (aid,))
    return db.get_one("SELECT * FROM automations WHERE id=?", (aid,))


# ------------------------------------------------------------------ brand kit
@app.get("/api/brandkit")
def brandkit(user: dict = Depends(auth.get_current_user)):
    rows = db.query("SELECT * FROM brand_kits WHERE user_id=? ORDER BY created_at DESC", (user["id"],))
    for r in rows:
        r["config"] = json.loads(r["config_json"] or "{}")
    return rows


@app.put("/api/brandkit")
def save_brandkit(body: BrandKitIn, user: dict = Depends(auth.get_current_user)):
    rows = db.query("SELECT * FROM brand_kits WHERE user_id=?", (user["id"],))
    cfg = json.dumps(body.config)
    if rows:
        db.update("brand_kits", {"name": body.name, "config_json": cfg},
                  "id=?", (rows[0]["id"],))
        return db.get_one("SELECT * FROM brand_kits WHERE id=?", (rows[0]["id"],))
    bid = db.new_id()
    db.insert("brand_kits", {"id": bid, "user_id": user["id"], "name": body.name,
                             "config_json": cfg, "created_at": db.now()})
    return db.get_one("SELECT * FROM brand_kits WHERE id=?", (bid,))


# ------------------------------------------------------------------ subscription
@app.get("/api/subscription")
def subscription(user: dict = Depends(auth.get_current_user)):
    sub = db.get_one("SELECT * FROM subscriptions WHERE user_id=?", (user["id"],))
    recent = db.query("SELECT metric, SUM(amount) total FROM usage WHERE user_id=? GROUP BY metric ORDER BY created_at DESC", (user["id"],))
    return {"subscription": sub, "usage": recent}


# ------------------------------------------------------------------ jobs/progress
@app.get("/api/jobs/{jid}")
def job_status(jid: str, user: dict = Depends(auth.get_current_user)):
    return jobs.get_progress(jid) or {"job_id": jid, "state": "unknown"}


# ------------------------------------------------------------------ media
@app.get("/media/{path:path}")
def media(path: str, sig: str = "", ttl: int = 3600):
    if not verify_signature(path, sig, ttl):
        raise HTTPException(403, "Invalid or expired media link.")
    p = safe_media_path(path)
    if not p:
        raise HTTPException(404, "File not found")
    return FileResponse(p)


# ------------------------------------------------------------------ health
@app.get("/api/health")
def health():
    return {"ok": True}


# ------------------------------------------------------------------ SPA
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    def spa():
        return FileResponse(str(FRONTEND_DIR / "index.html"))
