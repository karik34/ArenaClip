"""Storage layer. In dev this maps to local disk; the interface mirrors S3
object storage (buckets = projects) so it can be swapped to real S3/R2 later.

All media access is tenant-isolated and served via signed URLs.
"""
import hmac, hashlib, base64, time, shutil
from pathlib import Path
from fastapi.responses import FileResponse
from .config import STORAGE_DIR, JWT_SECRET, PUBLIC_BASE

BUCKETS = {"source", "clips", "thumbs", "audio", "temp", "music"}


def bucket(name):
    return STORAGE_DIR / name


def ensure_buckets():
    for b in BUCKETS:
        (bucket(b) / "dummy").mkdir(parents=True, exist_ok=True)


def write(rel_path, data):
    p = STORAGE_DIR / rel_path
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, (bytes, bytearray)):
        p.write_bytes(data)
    else:
        p.write_text(data)
    return rel_path


def delete(rel_path):
    p = STORAGE_DIR / rel_path
    try:
        if p.is_file():
            p.unlink()
    except FileNotFoundError:
        pass


def path_of(rel_path):
    return STORAGE_DIR / rel_path


def exists(rel_path):
    return (STORAGE_DIR / rel_path).exists()


def _sign(key):
    sig = hmac.new(JWT_SECRET.encode(), key.encode(), hashlib.sha256).hexdigest()
    return sig


def signed_url(rel_path, ttl_seconds=3600):
    key = f"{rel_path}:{int(time.time())//ttl_seconds}"
    sig = _sign(key)
    return f"/media/{rel_path}?sig={sig}&ttl={ttl_seconds}"


def verify_signature(rel_path, sig, ttl):
    try:
        ttl = int(ttl)
        now = int(time.time())
        # allow small clock skew: check current and previous window
        for t in range(-1, 2):
            key = f"{rel_path}:{(now//ttl)+t}"
            if hmac.compare_digest(_sign(key), sig or ""):
                return True
    except Exception:
        return False
    return False


def safe_media_path(rel_path: str) -> Path | None:
    """Resolve rel_path under storage and guard against traversal."""
    p = (STORAGE_DIR / rel_path).resolve()
    if not str(p).startswith(str(STORAGE_DIR.resolve())):
        return None
    if not p.exists() or not p.is_file():
        return None
    return p


def project_dir(project_id):
    return f"projects/{project_id}"


def cleanup_temp(project_id, keep_older_than=3600):
    d = bucket("temp") / f"projects/{project_id}"
    if not d.exists():
        return
    cutoff = time.time() - keep_older_than
    for f in d.rglob("*"):
        if f.is_file() and f.stat().st_mtime < cutoff:
            f.unlink()
