#!/usr/bin/env bash
# Launch ArenaClip backend + SPA.
set -e
cd "$(dirname "$0")"
export PYTHONPATH="$PWD"
exec uvicorn backend.app:app --host 0.0.0.0 --port "${PORT:-8000}"
