"""Central configuration. All secrets come from environment variables."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
STORAGE_DIR = Path(os.getenv("STORAGE_DIR", BASE_DIR / "storage"))
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
MUSIC_DIR = STORAGE_DIR / "music"

# Security
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRES_MINUTES = int(os.getenv("JWT_EXPIRES_MINUTES", "10080"))

# Auth
TOKEN_ENCRYPTION_KEY = os.getenv("TOKEN_ENCRYPTION_KEY", "dev-enc-key-change-me")

# Ingestion
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(2 * 1024**3)))  # 2 GB
SUPPORTED_VIDEO_EXT = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".ts", ".flv", ".mpg", ".mpeg", ".wmv"}
DOWNLOAD_MAX_BYTES = int(os.getenv("DOWNLOAD_MAX_BYTES", str(4 * 1024**3)))

# Transcription
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "base")  # tiny | base | small
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
WHISPER_COMPUTE = os.getenv("WHISPER_COMPUTE", "int8")

# Rendering
RENDER_WIDTH = int(os.getenv("RENDER_WIDTH", "1080"))
RENDER_HEIGHT = int(os.getenv("RENDER_HEIGHT", "1920"))
EXPORT_CRF = int(os.getenv("EXPORT_CRF", "23"))
FPS = int(os.getenv("FPS", "30"))

# Public base URL (used for signed media URLs)
PUBLIC_BASE = os.getenv("PUBLIC_BASE", "http://localhost:8000")

# Credits
DEFAULT_CREDITS = int(os.getenv("DEFAULT_CREDITS", "100"))
COST_PER_MINUTE_TRANSCRIBE = float(os.getenv("COST_PER_MINUTE_TRANSCRIBE", "0.003"))
COST_PER_CLIP_RENDER = float(os.getenv("COST_PER_CLIP_RENDER", "0.015"))

# Scheduler
SCHEDULER_TICK_SECONDS = int(os.getenv("SCHEDULER_TICK_SECONDS", "30"))

for d in (STORAGE_DIR, DATA_DIR, MUSIC_DIR):
    d.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "app.db"
