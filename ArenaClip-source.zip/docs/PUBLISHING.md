# Publishing to YouTube / TikTok / Instagram (real OAuth)

ArenaClip's publishing layer is fully implemented behind a `PublishProvider`
interface, but **live publishing needs OAuth credentials from each platform**
that can't be bundled in a sandbox. This page explains exactly how to wire them up.

## How it works today
- You can **connect an account** (demo mode stores the token encrypted at rest —
  never plaintext) and **schedule jobs** freely.
- A scheduled job without a valid connected account is marked **"Needs review"**
  with a clear, actionable message — it is **never** silently dropped or faked.
- Swapping in real publishing is a matter of implementing one method per platform
  in `backend/providers/publishing.py`.

## To enable real publishing

### YouTube (Shorts)
1. Create a project in the [Google Cloud Console](https://console.cloud.google.com),
   enable the **YouTube Data API v3**.
2. Create OAuth credentials (client ID + secret), scopes:
   `https://www.googleapis.com/auth/youtube.upload`
3. Set `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` in `.env`.
4. In `YouTubeProvider.publish()` add the standard
   `google-api-python-client` upload path using the user's OAuth token
   (the token is already decrypted for you from `token_enc`).
5. Upload the MP4 with `title`, `description`, `tags`, `categoryId=22` (Shorts).

### TikTok (Content Posting API)
1. Register on the TikTok for Developers console, request the **Content Posting API**
   (requires app review for the `video.publish` scope).
2. Set `TIKTOK_CLIENT_KEY` / `TIKTOK_CLIENT_SECRET`.
3. Implement the video upload + status-poll flow in `TikTokProvider.publish()`.

### Instagram (Reels)
1. Register a **Meta** app, add the Instagram product with
   `instagram_content_publish` + `instagram_business_basic` permissions.
2. Link an Instagram Business/Professional account.
3. Set `META_APP_ID` / `META_APP_SECRET`.
4. Implement the container-creation + publish flow in `InstagramProvider.publish()`.

## Principles
- **Idempotency:** the scheduler checks `external_id` before publishing, so a retry
  never double-publishes.
- **Retries:** transient failures are retried (3 attempts with backoff); permanent
  auth errors flip the job to `needs_review`.
- **Rate limits & quotas:** respect each API's limits; on quota errors the job is
  deferred rather than dropped.
