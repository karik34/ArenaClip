"""Authentication & authorization (JWT, bcrypt password hashing)."""
import bcrypt, jwt, datetime, re
from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from .config import JWT_SECRET, JWT_ALGORITHM, JWT_EXPIRES_MINUTES
from . import db

bearer = HTTPBearer(auto_error=False)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(pw):
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def verify_password(pw, hashed):
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except Exception:
        return False


def create_token(user_id):
    exp = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(
        minutes=JWT_EXPIRES_MINUTES)
    return jwt.encode({"sub": user_id, "exp": exp}, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload.get("sub")
    except Exception:
        return None


def get_current_user(req: Request,
                     creds: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    if not creds:
        raise HTTPException(401, "Not authenticated")
    user_id = decode_token(creds.credentials)
    if not user_id:
        raise HTTPException(401, "Invalid or expired token")
    user = db.get_one("SELECT * FROM users WHERE id=?", (user_id,))
    if not user:
        raise HTTPException(401, "User not found")
    user.pop("password_hash", None)
    return user


def require_owner(entity_table, entity_id, user_id):
    """Tenant isolation: ensure a row belongs to the current user."""
    row = db.get_one(f"SELECT * FROM {entity_table} WHERE id=?", (entity_id,))
    if not row or row["user_id"] != user_id:
        raise HTTPException(404, "Not found")
    return row
