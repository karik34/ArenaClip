import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.providers.transcription import TranscriptionProvider
from backend.providers import analysis as anl
from backend.providers.rendering import render_clip, probe as ffprobe
from backend.providers import broll

VIDEO = "/tmp/test_video.mp4"
res = TranscriptionProvider().transcribe(VIDEO)
cands = anl.find_moments(res["segments"], 12, 30)
cands.sort(key=lambda c: c["score"], reverse=True)
c = cands[0]
print(f"Rendering clip [{c['start']:.1f}-{c['end']:.1f}] score={c['score']}")

# words within range
words = [w for s in res["segments"] for w in s["words"]
         if c["start"] <= w["start"] <= c["end"]]
words.sort(key=lambda x: x["start"])

music = broll.ensure_music_library()["subtle"]
pi = ffprobe(VIDEO)
out = "/tmp/out_clip.mp4"
t0 = time.time()
render_clip(VIDEO, {"width": pi["width"], "height": pi["height"]},
            {"start": c["start"], "end": c["end"], "words": words},
            {"editing_intensity": "moderate", "caption_style": "dynamic",
             "music_volume": 0.16},
            out, music_path=music)
print(f"Rendered in {time.time()-t0:.1f}s -> {out}")
p = ffprobe(out)
for s in p["streams"]:
    print(f"  {s['codec_type']}: {s.get('width','')}x{s.get('height','')} {s.get('codec_name')}")
print("  duration:", p["format"]["duration"], "size:", round(int(p['format']['size'])/1024,1), "KB")
