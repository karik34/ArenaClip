"""Pipeline orchestrator. Each stage runs as an async background job with
retries, real progress, and project-scoped live events (SSE).

Upload/URL -> ingest -> transcribe -> analyze -> select -> edit/render ->
metadata -> queue/schedule/publish.
"""
import os, json, shutil, subprocess
from pathlib import Path
from . import db, jobs
from .config import STORAGE_DIR
from .providers import ingestion as ing
from .providers.transcription import TranscriptionProvider
from .providers import analysis as anl
from .providers.rendering import render_clip
from .providers import broll
from .providers import metadata as meta
from .providers.publishing import PROVIDERS

STAGES = ["Downloading video", "Extracting audio", "Transcribing",
          "Analyzing content", "Finding viral moments", "Creating clips",
          "Rendering"]


def _stage(project_id, idx, pct, message=""):
    name = STAGES[idx] if idx < len(STAGES) else STAGES[-1]
    payload = {"stage_index": idx, "stage": name, "progress": pct,
               "message": message}
    db.emit("project", "project", project_id, payload)
    jobs.publish_event(project_id, payload)


# ------------------------------------------------------------------ projects
def create_project(user_id, name, config, source_url=None):
    pid = db.new_id()
    db.insert("projects", {"id": pid, "user_id": user_id, "name": name,
                           "source_url": source_url, "status": "draft",
                           "config_json": json.dumps(config),
                           "created_at": db.now(), "updated_at": db.now()})
    db.insert("source_videos", {"id": db.new_id(), "project_id": pid,
                                "user_id": user_id, "filename": None, "path": None,
                                "url": source_url, "status": "pending",
                                "created_at": db.now()})
    return pid


def get_source_video(project_id):
    rows = db.query("SELECT * FROM source_videos WHERE project_id=? ORDER BY created_at LIMIT 1",
                    (project_id,))
    return rows[0] if rows else None


# ------------------------------------------------------------------ ingestion
def start_ingest_url(project_id, source_url):
    sv = get_source_video(project_id)
    db.update("source_videos", {"url": source_url, "status": "pending"},
              "id=?", (sv["id"],))
    db.update("projects", {"status": "processing", "source_url": source_url},
              "id=?", (project_id,))
    _stage(project_id, 0, 0, "Queued download")
    jobs.enqueue("process_source", sv["id"], _run_ingest_and_process,
                 table="source_videos", id=sv["id"], project_id=project_id,
                 source_url=source_url, uploaded=None)


def start_ingest_upload(project_id, tmp_upload_path, original_name):
    sv = get_source_video(project_id)
    ing.validate_upload(original_name)
    db.update("source_videos", {"filename": original_name, "status": "pending"},
              "id=?", (sv["id"],))
    db.update("projects", {"status": "processing"}, "id=?", (project_id,))
    _stage(project_id, 0, 0, "Upload received")
    jobs.enqueue("process_source", sv["id"], _run_ingest_and_process,
                 table="source_videos", id=sv["id"], project_id=project_id,
                 source_url=None, uploaded=tmp_upload_path)


def _run_ingest_and_process(source_url=None, uploaded=None, project_id=None, **kw):
    sv_id = kw["id"]
    sv = db.get_one("SELECT * FROM source_videos WHERE id=?", (sv_id,))
    # 1. ingest -> source file
    if uploaded:
        _stage(project_id, 0, 30, "Storing upload")
        src_dir = Path(STORAGE_DIR) / "source" / "projects" / project_id
        src_dir.mkdir(parents=True, exist_ok=True)
        dest = src_dir / ("upload_" + os.path.basename(uploaded))
        shutil.move(uploaded, dest)
        probe = ing.probe_video(str(dest))
        src_path = str(dest)
        src_title = sv.get("filename")
    else:
        _stage(project_id, 0, 5, "Starting download")
        prov = ing.IngestionProvider(Path(STORAGE_DIR) / "source" / "projects" / project_id)
        res = prov.download_url(source_url, progress_cb=lambda s, p, f: _stage(project_id, 0, 5 + p * 0.7, "Downloading video"))
        src_path = res["path"]
        probe = res["probe"]
        src_title = res.get("title")

    db.update("source_videos",
              {"path": src_path, "status": "ready", "duration": probe["duration"],
               "width": probe.get("width"), "height": probe.get("height"),
               "size_bytes": probe.get("size_bytes") or 0},
              "id=?", (sv_id,))
    _stage(project_id, 1, 100, "Video ready")
    _stage(project_id, 2, 2, "Extracting audio & transcribing")
    db.record_usage(sv["user_id"], "ingest", 0)

    # 2. transcribe
    try:
        _run_transcribe(sv_id, project_id)
    except Exception as e:
        db.update("source_videos", {"status": "failed", "error": str(e)}, "id=?", (sv_id,))
        db.update("projects", {"status": "failed"}, "id=?", (project_id,))
        raise


def _run_transcribe(sv_id, project_id):
    sv = db.get_one("SELECT * FROM source_videos WHERE id=?", (sv_id,))
    tr = db.query("SELECT * FROM transcripts WHERE source_video_id=?", (sv_id,))
    tr_id = tr[0]["id"] if tr else db.new_id()
    if not tr:
        db.insert("transcripts", {"id": tr_id, "source_video_id": sv_id,
                                  "status": "processing", "created_at": db.now()})
    prov = TranscriptionProvider()
    res = prov.transcribe(sv["path"],
                          progress_cb=lambda p: _stage(project_id, 2, 5 + p * 0.75, "Transcribing"))
    data = {"language": res["language"], "duration": res["duration"],
            "text": res["text"], "segments_json": json.dumps(res["segments"]),
            "status": "done", "error": None}
    db.update("transcripts", data, "id=?", (tr_id,))
    db.record_usage(sv["user_id"], "transcribe_minutes",
                    (res["duration"] or 0) / 60 * 0.003)
    _stage(project_id, 2, 100, "Transcript ready")
    _run_analyze_and_create(sv_id, project_id, tr_id)


def _run_analyze_and_create(sv_id, project_id, tr_id):
    project = db.get_one("SELECT * FROM projects WHERE id=?", (project_id,))
    config = json.loads(project["config_json"] or "{}")
    tr = db.get_one("SELECT * FROM transcripts WHERE id=?", (tr_id,))
    segments = json.loads(tr["segments_json"] or "[]")
    min_dur = float(config.get("min_duration", 20))
    max_dur = float(config.get("max_duration", 60))
    num_clips = int(config.get("num_clips", 6))
    min_score = float(config.get("min_score", 0))
    focus = config.get("focus") or []
    priority = config.get("priority") or []

    _stage(project_id, 3, 0, "Analyzing content")
    candidates = anl.find_moments(segments, min_dur, max_dur, focus=focus, priority=priority)
    _stage(project_id, 3, 100, f"{len(candidates)} candidate moments")
    _stage(project_id, 4, 0, "Scoring candidates")

    if not candidates:
        db.update("projects", {"status": "failed"}, "id=?", (project_id,))
        raise RuntimeError("No usable speech found in this video. Try a video with clear spoken audio.")

    candidates.sort(key=lambda c: c["score"], reverse=True)
    selected = [c for c in candidates if c["score"] >= min_score]
    if len(selected) < num_clips:
        # quality > quantity: still return the best available
        selected = candidates[:num_clips] if not selected else selected
    selected = selected[:num_clips]

    _stage(project_id, 4, 100, f"Selected {len(selected)} clips")
    _stage(project_id, 5, 10, "Creating clips")

    created = []
    for i, cand in enumerate(selected):
        clip_id = db.new_id()
        db.insert("clips", {"id": clip_id, "project_id": project_id,
                            "source_video_id": sv_id, "user_id": project["user_id"],
                            "start_ts": cand["start"], "end_ts": cand["end"],
                            "duration": cand["duration"], "status": "processing",
                            "score": cand["score"], "score_label": cand["score_label"],
                            "hook_snapshot": cand.get("hook_snapshot", ""),
                            "transcript": cand.get("text", ""),
                            "reason": cand.get("reason", ""),
                            "position": i,
                            "requires_approval": 1 if config.get("approval") == "manual" else 0,
                            "created_at": db.now()})
        db.insert("clip_scores", {"id": db.new_id(), "clip_id": clip_id,
                                  **{k: v for k, v in cand["scores"].items()}})
        created.append((clip_id, cand))
        _stage(project_id, 5, 10 + (i + 1) / len(selected) * 80, f"Created clip {i+1}")

    # enqueue rendering for each clip
    _stage(project_id, 5, 100, f"Queuing {len(created)} render jobs")
    for clip_id, cand in created:
        jobs.enqueue("render_clip", clip_id, _render_clip_job,
                     table="render_jobs", id=db.new_id(),
                     clip_id=clip_id, project_id=project_id)


def _render_clip_job(clip_id, project_id, **kw):
    job_id = kw.get("id")
    clip = db.get_one("SELECT * FROM clips WHERE id=?", (clip_id,))
    sv = db.get_one("SELECT * FROM source_videos WHERE id=?", (clip["source_video_id"],))
    tr = db.query("SELECT * FROM transcripts WHERE source_video_id=? ORDER BY created_at DESC LIMIT 1",
                  (clip["source_video_id"],))
    tr = tr[0] if tr else None
    project = db.get_one("SELECT * FROM projects WHERE id=?", (project_id,))
    config = json.loads(project["config_json"] or "{}")

    if job_id:
        db.insert("render_jobs", {"id": job_id, "clip_id": clip_id,
                                  "project_id": project_id, "user_id": clip["user_id"],
                                  "status": "running", "progress": 0,
                                  "created_at": db.now()})

    segments = json.loads(tr["segments_json"]) if tr and tr.get("segments_json") else []
    words = []
    for s in segments:
        for w in s.get("words", []):
            if clip["start_ts"] <= w["start"] <= clip["end_ts"]:
                words.append(w)
    words.sort(key=lambda x: x["start"])

    def prog(p):
        jobs.set_progress(job_id, stage="rendering", progress=p, message=f"{p:.0f}%")
        _stage(project_id, 6, p, "Rendering clip")

    brand = None
    bk = db.query("SELECT * FROM brand_kits WHERE user_id=? ORDER BY created_at DESC LIMIT 1",
                  (clip["user_id"],))
    if bk:
        brand = json.loads(bk[0]["config_json"] or "{}")

    music_style = config.get("music", "none")
    music_path = None
    if music_style and music_style != "none":
        music_path = broll.ensure_music_library().get(music_style)

    clips_out = Path(STORAGE_DIR) / "clips" / "projects" / project_id
    clips_out.mkdir(parents=True, exist_ok=True)
    out_path = str(clips_out / f"clip_{clip_id}.mp4")
    render_clip(sv["path"], {"width": sv["width"], "height": sv["height"]},
                {"start": clip["start_ts"], "end": clip["end_ts"], "words": words},
                {"editing_intensity": config.get("editing_intensity", "moderate"),
                 "caption_style": config.get("caption_style", "dynamic"),
                 "music_volume": float(config.get("music_volume", 0.16)),
                 "brand": brand or {}},
                out_path, music_path=music_path, progress_cb=prog,
                brand=brand)

    # thumbnail
    thumb_path = clips_out / f"thumb_{clip_id}.jpg"
    broll.make_thumbnail(out_path, clip["duration"] * 0.15, str(thumb_path))

    db.update("clips", {"status": "ready", "video_path": f"clips/projects/{project_id}/clip_{clip_id}.mp4",
                        "thumbnail_path": f"clips/projects/{project_id}/thumb_{clip_id}.jpg"},
              "id=?", (clip_id,))
    db.record_usage(clip["user_id"], "clips_rendered", 1)

    # metadata per platform
    platforms = config.get("platforms") or ["youtube_shorts"]
    for plat in platforms:
        md = meta.generate_metadata(clip["transcript"] or "", plat, brand=brand,
                                    focus=config.get("focus"))
        existing = db.query("SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?",
                            (clip_id, plat))
        md_id = existing[0]["id"] if existing else db.new_id()
        row = {"id": md_id, "clip_id": clip_id, "platform": plat, "status": "generated",
               "title": md["title"], "description": md["description"],
               "hashtags": md["hashtags"], "cta": md["cta"],
               "keywords": ",".join(md["keywords"]), "created_at": db.now()}
        if existing:
            db.update("clip_metadata", row, "id=?", (md_id,))
        else:
            db.insert("clip_metadata", row)

    _stage(project_id, 6, 100, f"Clip {clip_id[:8]} ready")
    _finalize_project_if_done(project_id)
    return out_path


def _finalize_project_if_done(project_id):
    clips = db.query("SELECT * FROM clips WHERE project_id=?", (project_id,))
    if not clips:
        return
    all_done = all(c["status"] in ("ready", "queued", "scheduled", "published")
                   for c in clips)
    if all_done:
        db.update("projects", {"status": "ready"}, "id=?", (project_id,))
        db.emit("project", "project", project_id,
                {"stage_index": 6, "stage": "Complete", "progress": 100,
                 "message": "All clips ready"})
        jobs.publish_event(project_id, {"stage_index": 6, "stage": "Complete",
                                        "progress": 100, "message": "All clips ready"})


# ------------------------------------------------------------------ publish/schedule
def queue_publish(clip_id, user_id, platform, account_id, scheduled_at_iso=None):
    pj = db.new_id()
    db.insert("publishing_jobs", {"id": pj, "clip_id": clip_id, "user_id": user_id,
                                  "platform": platform, "account_id": account_id,
                                  "status": "scheduled" if scheduled_at_iso else "queued",
                                  "scheduled_at": scheduled_at_iso or db.now(),
                                  "created_at": db.now()})
    if scheduled_at_iso:
        db.update("clips", {"status": "scheduled"}, "id=?", (clip_id,))
    return pj
