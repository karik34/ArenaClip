"""Provider abstraction layer. Every external/AI capability is behind an
interface so providers can be swapped without rewriting the application.

  IngestionProvider       -> yt-dlp / direct file
  TranscriptionProvider   -> faster-whisper (local, no API key)
  ClipAnalysisProvider    -> heuristic NLP analyzer
  CaptionProvider         -> word-timing -> ASS caption generator
  BrollProvider           -> procedural stock/music assets
  RenderingProvider       -> FFmpeg pipeline
  MetadataProvider        -> title/description/hashtags/CTA generator
  PublishProvider         -> YouTube/TikTok/Instagram (OAuth-gated)
"""
from . import ingestion, transcription, analysis, rendering, metadata, publishing, broll
