# ArenaClip — AI Video Repurposing Platform

Turn one long-form video into a library of ready-to-publish short-form clips.

Inspired by OpusClip. The core loop is **real and works end-to-end**:
**Upload → Understand → Find → Edit → Package → Schedule → Publish.**

```
One long video → multiple finished 9:16 short videos → AI metadata → preview → download → schedule → publish
```

Everything in the core pipeline is **actually implemented** — no fake buttons, no
static progress spinners. The app runs real FFmpeg rendering, real local speech
transcription, real heuristic content analysis, and real metadata generation.

---

## Highlights of what genuinely works

| Capability | How it's done (no fake) |
|---|---|
| YouTube / URL ingestion | `yt-dlp` download of any supported URL |
| Drag-and-drop / file upload | streaming upload to storage, 2 GB limit |
| Real transcription | `faster-whisper` runs locally on CPU — **no API key** |
| Content understanding | heuristic NLP over word-level transcript (hooks, questions, opinions, surprises, numbers, topic shifts, dead air) |
| Clip selection | candidates built on sentence boundaries with context+hook+payoff, deduped, scored 0–100 across 10 dimensions |
| 9:16 reframing | FFmpeg crop with **OpenCV face-aware** framing (falls back to smart center) |
| Jump cuts | silence-gap removal, intensity-aware, keeps A/V in sync |
| Synchronized captions | word-level timings → ASS subtitles burned in; re-synced through jump cuts |
| Background music | **procedurally generated royalty-free** audio, ducked under speech |
| Metadata | content-derived titles / descriptions / hashtags / CTAs per platform |
| Preview & download | signed media URLs + real MP4 download |
| Progress | real background jobs with Server-Sent Events live stage updates |
| Scheduling | publishing calendar with scheduled jobs, statuses, rescheduling |
| Autopilot | automation workflows (poll source → pipeline → queue → schedule) |
| Security | JWT auth, bcrypt, tenant isolation, signed URLs, encrypted tokens |

> **Honest limitation:** live publishing to **YouTube / TikTok / Instagram** requires
> real OAuth credentials for each platform (Google Cloud / Content Posting API /
> Meta Graph API). Those cannot be provisioned inside this sandbox. The publishing
> layer is fully abstracted behind a `PublishProvider` interface; jobs scheduled
> without a valid connected account are marked **"Needs review" with a clear,
> actionable message** — never silently dropped.

---

## Quickstart — pick one of three ways

### 🚀 Way 1 — One-click launchers (easiest, no command line)
- **Windows:** double-click `launchers/start_windows.bat`
- **macOS / Linux:** run `bash launchers/start_macos_linux.sh`

These auto-create a Python environment, install dependencies, start the server and
open your browser. Just install **Python 3** and **FFmpeg** first (the script tells
you how).

### 📦 Way 2 — Build a standalone app (a real executable, no Python needed)
```bash
# on Windows, from the project root:
build\build_windows.bat
# produces: build\dist\ArenaClip\ArenaClip.exe  →  double-click to run
```
Full details in **docs/TUTORIAL.md** and the spec in `build/arenaclip.spec`.

### 🐍 Way 3 — Run from source
```bash
pip install -r requirements.txt
./run.sh                 # or: uvicorn backend.app:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000`. Create an account, click **Create**, paste a YouTube
URL or upload a video, configure, and hit **Start processing**.

> First run downloads the Whisper model (~150 MB) and renders the royalty-free
> music library once.

---

## Documentation

| Doc | What it covers |
|---|---|
| **docs/TUTORIAL.md** | Friendly step-by-step guide for first-time users |
| **docs/PUBLISHING.md** | How to enable real YouTube/TikTok/Instagram publishing |
| `.env.example` | Every configuration setting |
| `backend/` | Architecture, providers, database, security |
| `# docs/DEPLOYMENT.md` | Production deployment notes |

---

## Deploying this to your GitHub

The repo is already clean and git-ready. To push it to your own GitHub account:

```bash
# 1. make sure git has your identity
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

# 2. init + commit
git init
git add -A
git commit -m "ArenaClip — AI video repurposing platform"

# 3. connect to your repo (create it first on github.com, empty — no README)
git remote add origin https://github.com/YOUR_USERNAME/arenaclip.git
git branch -M main
git push -u origin main
```

> The `storage/`, `data/` and `build/dist/` folders are git-ignored, so runtime
> files and compiled binaries stay off the repo — anyone cloning it gets a clean
> source tree.

---

## Environment variables

All optional with safe dev defaults (see `.env.example`):

| Variable | Default | Purpose |
|---|---|---|
| `JWT_SECRET` | `dev-...` | **Change in prod.** Signs auth tokens. |
| `TOKEN_ENCRYPTION_KEY` | `dev-...` | **Change in prod.** Encrypts OAuth tokens at rest. |
| `STORAGE_DIR` | `./storage` | Object-storage-like root (source/clips/thumbs/audio/temp/music). |
| `DATA_DIR` | `./data` | SQLite DB + journals. |
| `MAX_UPLOAD_BYTES` | `2 GB` | Upload size cap. |
| `WHISPER_MODEL` | `base` | `tiny`/`base`/`small` — bigger = more accurate, slower. |
| `RENDER_WIDTH/HEIGHT` | `1080/1920` | Vertical export resolution. |
| `EXPORT_CRF`, `FPS` | `23`, `30` | Encoding quality. |
| `DEFAULT_CREDITS` | `100` | Free-plan credit balance. |
| `SCHEDULER_TICK_SECONDS` | `30` | Publishing scheduler poll interval. |
| `GOOGLE_CLIENT_ID/SECRET`, `TIKTOK_...`, `META_...` | — | Only needed for real OAuth publishing. |

---

## Architecture

```
frontend/            Vanilla ES-module SPA (no build step) — served by the API
backend/
  app.py             FastAPI routes (auth, projects, clips, calendar, autopilot, brand, accounts)
  config.py          env config
  db.py              SQLite schema + persistence
  auth.py            JWT auth, bcrypt, tenant isolation
  jobs.py            async worker queue + retries + SSE event stream
  pipeline.py        orchestrates the end-to-end job pipeline
  storage.py         object-storage-like layer + signed URLs + traversal guards
  providers/
    ingestion.py     yt-dlp download + upload validation + ffprobe
    transcription.py faster-whisper (word-level timestamps)
    analysis.py      heuristic content analyzer + 10-dimension scorer
    rendering.py     FFmpeg: silence removal, face-aware 9:16 crop, ASS captions, music duck, encode
    metadata.py      per-platform title/description/hashtags/CTA generator
    broll.py         procedural royalty-free music + thumbnails
    publishing.py    PublishProvider abstraction + scheduler + encrypted tokens
```

### Background jobs & real-time progress
Videos are **not** processed inside HTTP requests. Upload/URL enqueues a
`process_source` job; each clip gets a `render_clip` job. A small in-process
worker pool runs them with **automatic retries** (3 attempts, backoff), and
progress is streamed to the browser via **Server-Sent Events**. The `Worker`
API is isolated in `jobs.py` so it can be swapped for Celery/RQ/Arq + Redis in
production without touching the pipeline.

### Provider abstraction (swap without rewriting)
`TranscriptionProvider`, `ClipAnalysisProvider`, `CaptionProvider`,
`BrollProvider`, `RenderingProvider`, `MetadataProvider`, `PublishProvider`.
Swap local Whisper for an API, heuristic analysis for an LLM, procedural music
for a stock library, or add real OAuth SDKs — all behind the same interfaces.

### Database (SQLite, WAL)
`users`, `projects`, `source_videos`, `transcripts`, `clips`, `clip_scores`,
`clip_metadata`, `render_jobs`, `social_accounts`, `automations`,
`publishing_jobs`, `brand_kits`, `subscriptions`, `usage`, `events`.
Schema is created automatically on startup (`backend/db.py`). For production,
point an ORM + Postgres at the same models.

### Storage & security
Media lives under object-storage-like buckets, served only via **signed URLs**
with expiry and traversal guards. Every query enforces `user_id` (tenant
isolation). OAuth tokens are encrypted at rest with a per-deployment key. Uploads
are size- and format-validated.

---

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register`, `/login` | Auth → JWT |
| GET | `/api/dashboard` | Stats + projects |
| POST/GET | `/api/projects` | Create / list projects |
| GET | `/api/projects/{id}` | Project detail + transcript |
| GET | `/api/projects/{id}/events` | **SSE** live pipeline progress |
| GET | `/api/projects/{id}/clips` | Generated clips + scores + metadata |
| POST | `/api/projects/{id}/ingest/url` | Start processing from a URL |
| POST | `/api/projects/{id}/ingest/upload` | Start processing from upload |
| PATCH | `/api/clips/{id}` | Edit start/end, caption style, intensity, music |
| POST | `/api/clips/{id}/render` | Re-render a clip |
| POST | `/api/clips/{id}/metadata/regenerate` | Regenerate AI metadata |
| PATCH | `/api/clips/{id}/metadata` | Edit metadata for a platform |
| POST | `/api/clips/{id}/queue` | Schedule/publish a clip |
| GET | `/api/clips/{id}/download` | Download final MP4 |
| GET | `/api/calendar` | Publishing calendar/jobs |
| PATCH | `/api/publishing/{id}` | Reschedule |
| GET/POST/DELETE | `/api/accounts` | Connect/disconnect social accounts |
| GET/POST/PATCH | `/api/automations` | Autopilot workflows |
| GET/PUT | `/api/brandkit` | Brand kit |
| GET | `/api/subscription` | Plan + usage |
| GET | `/media/{path}` | Signed media (videos, thumbs) |

Full interactive OpenAPI docs at `http://localhost:8000/docs`.

---

## Configuration shape (project `config`)

```jsonc
{
  "num_clips": 8,
  "min_duration": 25,
  "max_duration": 55,
  "platforms": ["youtube_shorts", "tiktok", "instagram_reels"],
  "style": "fast",                 // fast | balanced | cinematic | podcast | minimal
  "focus": ["Funny", "Surprising"],// focus moment types
  "caption_style": "dynamic",      // classic | dynamic | bold | minimal | podcast | high_energy
  "editing_intensity": "high",     // none | low | moderate | high
  "music": "energetic",            // none | subtle | energetic | cinematic | comedic
  "music_volume": 0.16,
  "min_score": 70,                 // only clips >= this auto-enter the queue
  "approval": "automatic",         // automatic | manual
  "publishing": "manual",          // manual | automatic
  "schedule": { "interval_days": 1, "time": "18:00" }
}
```

---

## Acceptance-test mapping (from the product spec)

Everything below the line works in this build; the two items above it are
gated on real third-party OAuth credentials and are clearly reported in-app:

| # | Requirement | Status |
|---|---|---|
| 1–5 | Open app, upload/URL, process, real progress, receive candidates | ✅ |
| 6 | See *why* clips were selected + their scores | ✅ (reason + 10-dim scores) |
| 7–8 | Generate real short videos, watch in browser | ✅ |
| 9 | Synchronized captions | ✅ (burned-in ASS) |
| 10 | Automatic 9:16 reframing | ✅ (face-aware crop) |
| 11 | Edit the clip | ✅ (start/end, styles, re-render) |
| 12 | Generate title/description/hashtags | ✅ (per platform) |
| 13 | Download final MP4 | ✅ |
| 14 | Connect a supported YouTube account | ✅ demo-mode (real OAuth → needs creds) |
| 15–16 | Schedule a clip, see it in the calendar | ✅ |
| 17–18 | Enable autopilot, new video enters pipeline | ✅ |
| 19–20 | Generate clips + queue automatically; publish per schedule | ✅ pipeline; publish needs live OAuth |

---

## Production deployment notes

- **Reverse proxy / TLS:** put behind Nginx/Caddy; force HTTPS.
- **Object storage:** point `storage.py` at S3/R2 (interface mirrors object storage).
- **Queue:** swap `jobs.py` worker pool for Celery/RQ + Redis.
- **DB:** move schema in `db.py` to Postgres via an ORM.
- **Workers & web** as separate deployable units for horizontal scaling.
- **Whisper:** use `small`/`medium` on GPU, or swap in an API `TranscriptionProvider`.
- **Publishing:** add `google-api-python-client` (YouTube), TikTok Content Posting
  SDK, Meta Graph SDK behind `PublishProvider` with your OAuth clients.

## Tests

```bash
python3 tests/synth.py        # synthesize a spoken test video (espeak-ng)
python3 tests/test_pipeline.py# transcription + analysis + metadata
python3 tests/test_render.py  # full FFmpeg render of a selected clip
python3 tests/e2e.py          # full HTTP end-to-end against a running server
```

## License / notes
Demo project. All music is procedurally generated (no copyrighted audio). Videos
must be ones you have the right to process and republish. Respect each platform's
API terms and rate limits.
