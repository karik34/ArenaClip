"""Procedural royalty-free audio + thumbnail generation.

Music is synthesized from sine tones (no copyrighted material). A real product
can point this at a licensed stock-music API behind the same provider.
"""
import subprocess, os
from ..config import MUSIC_DIR

# Each style -> chord progressions (bars of note frequencies).
CHORDS = {
    "subtle":    [[261.6, 329.6, 392.0], [293.7, 349.2, 440.0]],
    "energetic": [[329.6, 415.3, 493.9], [392.0, 493.9, 587.3]],
    "cinematic": [[220.0, 261.6, 329.6], [196.0, 246.9, 293.7]],
    "comedic":   [[392.0, 466.2, 523.3], [349.2, 415.3, 466.2]],
}
TEMPO = {"subtle": 0.6, "energetic": 1.6, "cinematic": 0.4, "comedic": 1.0}
BAR = 4.0  # seconds per bar


def generate_music(style="subtle", duration=30, out_path=None):
    style = style if style in CHORDS else "subtle"
    out_path = out_path or os.path.join(MUSIC_DIR, f"proc_{style}.wav")
    bars = CHORDS[style]
    nbars = max(1, int(duration / BAR))
    sources, amix = [], []
    idx = 0
    for b in range(nbars):
        bar = bars[b % len(bars)]
        for j, freq in enumerate(bar):
            tag = f"n{idx}"
            idx += 1
            # note fades in/out within its bar to create a pad feel
            start = (b * BAR) % duration
            sources.append(
                f"aevalsrc=sin(2*PI*{freq}*t)*0.35:s=44100:d={nbars*BAR}[{tag}]")
            amix.append(f"[{tag}]volume='if(lt(mod(t\\,{BAR}),0.1),0,0.35)':eval=frame[a{idx}]")
        idx += 1
    # simpler: sum all tones then apply tremolo/vibrato
    fc = ";".join(sources)
    mix = "".join(f"[{t}]" for t in [s.split('[')[1].split(']')[0] for s in sources])
    mix = mix + f"amix=inputs={len(sources)}:normalize=0[mix]"
    vib = (f"[mix]tremolo=f={TEMPO[style]}:d=0.4,lowpass=f=1200,"
           f"afade=t=in:st=0:d=0.5,afade=t=out:st={nbars*BAR-0.5}:d=0.5[out]")
    args = ["-y", "-filter_complex", fc + ";" + mix + ";" + vib,
            "-map", "[out]", "-c:a", "pcm_s16le", out_path]
    r = subprocess.run(["ffmpeg"] + args, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out_path):
        # fallback: simple ambient drone
        args = ["-y", "-f", "lavfi",
                "-i", f"anoisesrc=color=pink:d={duration}:amplitude=0.05",
                "-f", "lavfi", "-i", f"sine=frequency=220:duration={duration}",
                "-filter_complex",
                "[0:a]volume=0.5[a];[1:a]volume=0.15,tremolo=f=0.2:d=0.5[b];"
                "[a][b]amix=inputs=2:normalize=0,lowpass=f=800[out]",
                "-map", "[out]", "-c:a", "pcm_s16le", out_path]
        subprocess.run(["ffmpeg"] + args, capture_output=True)
    return out_path


def ensure_music_library():
    for style in CHORDS:
        p = os.path.join(MUSIC_DIR, f"proc_{style}.wav")
        if not os.path.exists(p) or os.path.getsize(p) < 10000:
            generate_music(style, 45, p)
    return {s: os.path.join(MUSIC_DIR, f"proc_{s}.wav") for s in CHORDS}


def make_thumbnail(source, at, out_path):
    subprocess.run(["ffmpeg", "-y", "-ss", str(max(0, at)), "-i", source,
                    "-frames:v", "1", "-q:v", "3", out_path], capture_output=True)
    return out_path if os.path.exists(out_path) else None
