# ArenaClip — Friendly Tutorial

Turn **one long video** into **a whole row of ready-to-post short clips**, fully
automatically. This guide walks you through your first project in ~5 minutes.

---

## 1. Start ArenaClip

### Option A — Run the built app (easiest)
On Windows: double-click **`ArenaClip.exe`** (inside the `dist/ArenaClip/` folder
from the build step).
On macOS/Linux: double-click or run the **`ArenaClip`** binary.

A terminal opens, your browser opens, and you're in.

### Option B — One-click launcher from source
- **Windows:** double-click `launchers/start_windows.bat`
- **macOS / Linux:** run `bash launchers/start_macos_linux.sh`

These auto-create a Python environment, install dependencies, and start the app.
You just need **Python 3** and **FFmpeg** installed first (the script tells you
how if they're missing).

### Option C — Manual
```bash
pip install -r requirements.txt
./run.sh            # or: uvicorn backend.app:app --host 0.0.0.0 --port 8000
```
Then open `http://localhost:8000`.

> **First run** downloads the speech-to-text model (~150 MB) and generates the
> royalty-free music library once. After that it's instant.

---

## 2. Create your account

Click **Create account**, enter a name, email and password. That's it — you're
on the Dashboard.

---

## 3. Create a project

1. Click **Create** in the sidebar.
2. **Give it a source:**
   - Paste a **YouTube URL** (or any supported video link), **or**
   - Drag & drop a video file.
3. **Configure the AI:**
   - How many clips (e.g. `8`)
   - Min / max clip length (e.g. `25`–`55` seconds)
   - Target platforms (YouTube Shorts / TikTok / Instagram Reels)
   - Content style and what to focus on (funny, surprising, controversial…)
   - Caption style, editing intensity, music
   - Minimum AI score (clips below this won't auto-queue)
4. Click **⚡ Start processing**.

---

## 4. Watch it work (this is real)

You'll see a live pipeline, updating in real time:

```
Downloading video      ✓
Transcribing           ✓
Analyzing content      ████████░░ 82%
Finding viral moments  ██████░░░░ 61%
Creating clips         ██░░░░░░░░
Rendering              ░░░░░░░░░░
```

These are actual background jobs — not a fake spinner. When a clip is done you
see its card with an **AI score**, a thumbnail, and its duration.

---

## 5. Pick your clips

Each clip shows:
- **Score** (e.g. `87/100`) and a label (Excellent / Strong / Good…)
- **Hook** — the first line, so you know what it's about
- A **10-dimension breakdown** (hook strength, curiosity, entertainment, pacing…)
- The transcript and a plain-English reason it was picked

Open any clip to see the full score panel and its **generated title, description,
hashtags and CTA** (auto-written per platform from the actual content).

---

## 6. Edit a clip

In the **Clip Editor** you can change:
- Start / end time
- Caption style, editing intensity, background music + volume
- The title, description, hashtags and CTA for each platform
- Click **Re-render** to apply timing/style changes (re-runs the real pipeline)

---

## 7. Download or schedule

- **Download MP4** — get the finished 9:16 video (with burned-in captions, jump
  cuts, reframing and music).
- **Publish tab** — pick a platform and a date/time, then **Schedule to calendar**.
  Your clip appears in the **Calendar**.

> 💡 Real automatic publishing to YouTube/TikTok/Instagram needs OAuth
> credentials for each platform (see `docs/PUBLISHING.md`). Without them,
> scheduled jobs are marked **"Needs review"** with a clear message — nothing is
> silently dropped.

---

## 8. Turn on Autopilot

In **Autopilot**, create a workflow pointing at a source (e.g. your YouTube
channel). When a new video is detected it automatically runs the whole pipeline,
generates clips, scores them, and queues them for your schedule — no manual work.

---

## Pro tips

- **Quality over quantity:** raise the **minimum AI score** to get fewer, better clips.
- **Content focus:** use the focus tags ("Business advice", "Strong opinions"…)
  so the AI hunts for the moments you actually want.
- **Brand Kit:** set your fonts, colors, caption style and default CTA once — every
  clip then uses them automatically.

## Troubleshooting

| Problem | Fix |
|---|---|
| "FFmpeg not found" | Windows: `winget install Gyan.FFmpeg` · macOS: `brew install ffmpeg` |
| Video won't download | It may be private/region-locked/too long. Try another URL or upload the file. |
| Processing is slow | Transcription + rendering are CPU-bound; a shorter source or fewer clips is faster. |
| Captions look plain | Try **Dynamic** or **High Energy** caption styles. |
| Publish shows "Needs review" | Connect an account / add OAuth credentials (see `docs/PUBLISHING.md`). |

---

That's it — you now have a short-form content machine. 🎬
