"""Video ingestion: download from URL (yt-dlp) or direct upload, then probe."""
import subprocess, re, os, json
from pathlib import Path
from ..config import DOWNLOAD_MAX_BYTES, SUPPORTED_VIDEO_EXT, STORAGE_DIR

# yt-dlp python API is more robust than the CLI for metadata + errors
import yt_dlp


def is_video_url(url: str) -> bool:
    u = url.strip().lower()
    return u.startswith(("http://", "https://"))


def validate_url(url: str) -> dict:
    """Validate URL shape. Returns dict with platform hint."""
    if not is_video_url(url):
        raise ValueError("That does not look like a valid URL. Use a direct video link or a YouTube URL.")
    host = re.sub(r"^www\.", "", (url.split("/")[2] if url.startswith("http") else url).lower())
    platform = "generic"
    if "youtube.com" in host or "youtu.be" in host:
        platform = "youtube"
    elif "tiktok.com" in host:
        platform = "tiktok"
    elif "instagram.com" in host or "x.com" in host or "twitter.com" in host:
        platform = "social"
    elif host in ("vimeo.com", "dailymotion.com", "twitch.tv"):
        platform = host.split(".")[0]
    return {"url": url, "host": host, "platform": platform}


def probe_video(path) -> dict:
    cmd = ["ffprobe", "-v", "quiet", "-print_format", "json",
           "-show_format", "-show_streams", path]
    out = subprocess.run(cmd, capture_output=True, text=True)
    if out.returncode != 0:
        raise RuntimeError("Could not read video file: " + out.stderr[-300:])
    data = json.loads(out.stdout)
    dur, w, h = None, None, None
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not w:
            w, h = s.get("width"), s.get("height")
        if s.get("codec_type") == "audio" and dur is None:
            dur = float(s.get("duration") or 0)
    if dur is None:
        dur = float(data.get("format", {}).get("duration") or 0)
    return {"duration": dur, "width": w, "height": h,
            "size_bytes": int(data.get("format", {}).get("size") or 0)}


class IngestionProvider:
    """Downloads a source video to local storage and returns (path, probe)."""

    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def download_url(self, url: str, progress_cb=None) -> dict:
        validate_url(url)
        opts = {
            "outtmpl": str(self.output_dir / "source.%(ext)s"),
            "format": "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "progress_hooks": [self._hook(progress_cb)],
            "restrictfilenames": True,
            "max_filesize": DOWNLOAD_MAX_BYTES,
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
        except yt_dlp.utils.DownloadError as e:
            msg = str(e)
            if "requested format" in msg or "Unsupported" in msg or "unable to download" in msg:
                raise ValueError("That video could not be downloaded (may be private, region-locked, or unsupported). " + msg[:200])
            raise ValueError("Download failed: " + msg[:300])
        file = self._find_downloaded()
        if not file:
            raise ValueError("Download produced no file. The video may be unavailable or protected.")
        probe = probe_video(file)
        return {"path": str(file), "probe": probe,
                "title": (info or {}).get("title"), "source_url": url}

    def _hook(self, cb):
        def hook(d):
            if d.get("status") == "downloading" and cb:
                total = d.get("total_bytes") or d.get("total_bytes_estimate")
                done = d.get("downloaded_bytes", 0)
                pct = (done / total * 100) if total else 0
                cb("downloading", pct, d.get("filename"))
            elif d.get("status") == "finished" and cb:
                cb("downloading", 100, d.get("filename"))
        return hook

    def _find_downloaded(self):
        cands = list(self.output_dir.glob("source.*"))
        if cands:
            return max(cands, key=lambda p: p.stat().st_size)


def validate_upload(filename: str) -> None:
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED_VIDEO_EXT:
        raise ValueError(f"Unsupported file type '{ext or 'unknown'}'. Supported: {', '.join(sorted(SUPPORTED_VIDEO_EXT))}")
