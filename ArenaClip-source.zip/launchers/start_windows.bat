@echo off
title ArenaClip - AI Video Repurposing
echo.
echo  ============================================================
echo    ArenaClip  -  AI Video Repurposing Studio
echo  ============================================================
echo.
echo  This will set everything up for you the first time
echo  (install Python packages + make sure FFmpeg is present),
echo  then open ArenaClip in your browser.
echo.

cd /d "%~dp0"

REM ---- 1. Make sure Python is installed ----
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo  [!] Python was not found.
    echo      Install it from https://www.python.org/downloads/
    echo      (tick "Add Python to PATH" during install), then run this again.
    pause
    exit /b 1
)

REM ---- 2. Make sure FFmpeg is installed ----
where ffmpeg >nul 2>nul
if %errorlevel% neq 0 (
    echo  [!] FFmpeg was not found.
    echo      Run this to install it automatically:
    echo.
    echo          winget install Gyan.FFmpeg
    echo.
    echo      (or download from https://ffmpeg.org/download.html )
    pause
    exit /b 1
)

REM ---- 3. Create virtual environment + install deps ----
if not exist ".venv" (
    echo  [1/3] Creating a private Python environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat
echo  [2/3] Installing/updating dependencies...
python -m pip install --upgrade pip >nul 2>nul
pip install -r requirements.txt

REM ---- 4. Launch ----
echo  [3/3] Starting ArenaClip...
echo.
echo  ------------------------------------------------------------
echo    Opening your browser at  http://127.0.0.1:8000
echo    Press Ctrl+C in this window to stop the server.
echo  ------------------------------------------------------------
echo.
start "" http://127.0.0.1:8000
set PYTHONPATH=%~dp0
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
pause
