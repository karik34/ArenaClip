"""Transcription via faster-whisper (local, no API key). Returns segments with
word-level timestamps, which power accurate captions and moment detection."""
import json, time
from ..config import WHISPER_MODEL, WHISPER_DEVICE, WHISPER_COMPUTE

_model = None
_model_lock = None


class TranscriptionProvider:
    def __init__(self, model=WHISPER_MODEL):
        global _model, _model_lock
        self.model_name = model
        if _model is None:
            from threading import Lock
            _model_lock = Lock()
            from faster_whisper import WhisperModel
            _model = WhisperModel(model, device=WHISPER_DEVICE,
                                  compute_type=WHISPER_COMPUTE)
        self.model = _model

    def transcribe(self, video_path, progress_cb=None) -> dict:
        segments, info = self.model.transcribe(
            video_path, beam_size=1, vad_filter=True,
            word_timestamps=True, condition_on_previous_text=True,
        )
        seg_list = []
        words_all = []
        for seg in segments:
            words = []
            for w in (seg.words or []):
                words.append({"word": w.word, "start": round(w.start, 3),
                              "end": round(w.end, 3), "prob": round(w.probability, 3)})
            seg_list.append({
                "id": len(seg_list), "start": round(seg.start, 3),
                "end": round(seg.end, 3), "text": seg.text.strip(),
                "words": words,
            })
            words_all.extend(words)
            if progress_cb:
                progress_cb(min(100, int(seg.end / max(info.duration, 0.001) * 100)))
        text = " ".join(s["text"] for s in seg_list).strip()
        return {"language": info.language, "duration": info.duration,
                "text": text, "segments": seg_list}
