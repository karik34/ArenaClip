"""FFmpeg rendering provider.

Real editing pipeline per clip:
  1. silence detection -> jump-cut removal (intensity-aware)
  2. face-aware 9:16 crop (OpenCV Haar) with center fallback
  3. per-segment render + concat (keeps A/V sync through jump cuts)
  4. re-synced ASS captions burned in (per-word timing)
  5. optional ducked background music + loudnorm + noise reduction
  6. final H.264/AAC 1080x1920 MP4
"""
import subprocess, json, re, os, math, tempfile
from pathlib import Path
from ..config import RENDER_WIDTH, RENDER_HEIGHT, EXPORT_CRF, FPS, STORAGE_DIR

FFMPEG = "ffmpeg"
FFPROBE = "ffprobe"

STYLES = {
    "classic": dict(size=58, color="&H00FFFFFF", outline=3, shadow=1, pos_h=0.78,
                    upper=False, margin=70, font="Arial", bold=False),
    "dynamic": dict(size=64, color="&H00FFFFFF", outline=4, shadow=2, pos_h=0.74,
                    upper=True, margin=60, font="Arial Black", bold=True),
    "bold":    dict(size=72, color="&H00FFFFFF", outline=5, shadow=3, pos_h=0.72,
                    upper=False, margin=50, font="Arial", bold=True),
    "minimal": dict(size=54, color="&H00FFFFFF", outline=1, shadow=1, pos_h=0.80,
                    upper=False, margin=80, font="Arial", bold=False),
    "podcast": dict(size=60, color="&H00FFFFFF", outline=3, shadow=2, pos_h=0.76,
                    upper=False, margin=70, font="DejaVu Sans", bold=False),
    "high_energy": dict(size=70, color="&H0000FFFF", outline=4, shadow=2, pos_h=0.70,
                        upper=True, margin=50, font="Arial Black", bold=True),
}


# ---------------------------------------------------------------- ffmpeg util
def run_ffmpeg(args, progress_cb=None, total_seconds=None, log_path=None):
    cmd = [FFMPEG, "-y", "-hide_banner", "-nostats", "-progress", "pipe:1"] + args
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True)
    last = {}
    for line in proc.stdout:
        line = line.strip()
        if "=" in line:
            k, v = line.split("=", 1)
            last[k] = v
            if k == "out_time_ms" and progress_cb and total_seconds:
                try:
                    t = int(v) / 1_000_000
                    progress_cb(max(0, min(100, t / total_seconds * 100)))
                except Exception:
                    pass
    err = proc.stderr.read()
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError("ffmpeg failed:\n" + err[-800:])
    if log_path:
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        Path(log_path).write_text(err[-4000:])
    return err


def probe(path):
    out = subprocess.run([FFPROBE, "-v", "quiet", "-print_format", "json",
                          "-show_streams", "-show_format", path],
                         capture_output=True, text=True)
    return json.loads(out.stdout)


# ---------------------------------------------------------------- silence
def detect_silence(source, start, end, noise_db=-30, min_sil=0.30):
    """Return list of (gap_start, gap_end) absolute-source-time silence gaps."""
    args = [FFMPEG, "-ss", str(max(0, start - 0.2)), "-to", str(end + 0.2),
            "-i", source, "-af",
            f"silencedetect=noise={noise_db}dB:d={min_sil}", "-f", "null", "-"]
    out = subprocess.run(args, capture_output=True, text=True).stderr
    starts, ends = [], []
    for line in out.splitlines():
        m = re.search(r"silence_start: ([\d.]+)", line)
        if m:
            starts.append(float(m.group(1)) + max(0, start - 0.2))
        m = re.search(r"silence_end: ([\d.]+)", line)
        if m:
            ends.append(float(m.group(1)) + max(0, start - 0.2))
    gaps = []
    for i, s in enumerate(starts):
        e = ends[i] if i < len(ends) else s + min_sil
        e = min(e, end)
        s = max(s, start)
        if e - s >= 0.1:
            gaps.append((s, e))
    return gaps


def retained_ranges(start, end, gaps, intensity):
    """Remove silence gaps longer than the intensity threshold, preserving
    head/tail of the clip. Returns list of (rs, re) retained sub-ranges."""
    thresholds = {"none": 1.6, "low": 1.1, "moderate": 0.7,
                  "high": 0.42, "max": 0.28}
    th = thresholds.get(intensity, 0.7)
    cut = [g for g in gaps if (g[1] - g[0]) > th]
    # keep clip start/end (never cut the very first/last 0.5s)
    keep_head = start + 0.5
    keep_tail = end - 0.5
    cut = [(s, e) for s, e in cut if s > keep_head and e < keep_tail]
    ranges = []
    cursor = start
    for (gs, ge) in cut:
        if gs - cursor >= 0.6:  # only keep non-trivial retained chunks
            ranges.append((cursor, gs))
        cursor = ge
    if end - cursor >= 0.4:
        ranges.append((cursor, end))
    if not ranges:
        ranges = [(start, end)]
    return ranges


# ---------------------------------------------------------------- smart crop
_face_cascade = None


def _get_cascade():
    global _face_cascade
    if _face_cascade is None:
        import cv2
        _face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    return _face_cascade


def smart_crop_offset(source, start, end, probe_info, samples=7):
    """Return (x, y, crop_w, crop_h) region to crop from source for 9:16.
    x/y are the top-left offset; centers on detected faces when available."""
    W, H = probe_info.get("width") or 1920, probe_info.get("height") or 1080
    target_ar = RENDER_WIDTH / RENDER_HEIGHT  # 9/16
    src_ar = W / H
    crop_w, crop_h, cx, cy = W, H, W / 2, H / 2
    if src_ar > target_ar:
        crop_w = int(H * target_ar)
        crop_h = H
    elif src_ar < target_ar:
        crop_w = W
        crop_h = int(W / target_ar)
    else:
        return 0, 0, W, H

    # sample frames to find dominant face center
    face_x, face_y = None, None
    try:
        cascade = _get_cascade()
        tmp = tempfile.mktemp(suffix=".png")
        dur = max(0.5, end - start)
        for i in range(samples):
            t = start + dur * (i / max(1, samples - 1))
            subprocess.run([FFMPEG, "-y", "-ss", str(t), "-i", source,
                            "-frames:v", "1", "-q:v", "2", tmp],
                           capture_output=True)
            import cv2, numpy as np
            img = cv2.imread(tmp)
            if img is None:
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, 1.1, 4, minSize=(40, 40))
            for (fx, fy, fw, fh) in faces:
                face_x = fx + fw / 2
                face_y = fy + fh / 2
        if os.path.exists(tmp):
            os.unlink(tmp)
    except Exception:
        face_x = None

    if face_x is not None:
        x = int(face_x - crop_w / 2)
    else:
        x = int((W - crop_w) / 2)
    if face_y is not None:
        y = int(face_y - crop_h / 2)
    else:
        y = int((H - crop_h) / 2)
    x = max(0, min(W - crop_w, x))
    y = max(0, min(H - crop_h, y))
    return x, y, crop_w, crop_h


# ---------------------------------------------------------------- captions
def build_ass(words, removed_gaps, clip_start, style_key="dynamic", brand=None):
    """Build ASS subtitle content. `words` are absolute source-time word dicts.
    Returns ass text. Also returns total removed time function via mapping."""
    st = STYLES.get(style_key, STYLES["dynamic"])
    removed = sorted(removed_gaps, key=lambda g: g[0])

    def removed_before(t):
        total = 0.0
        for (s, e) in removed:
            if e <= t:
                total += e - s
            elif s < t:
                total += t - s
            else:
                break
        return total

    def clip_time(t):
        return (t - clip_start) - removed_before(t)

    events = []
    cur_words = []
    cur_s = cur_e = None
    for w in words:
        if w["start"] < clip_start or w["end"] > removed[-1][1] if removed else False:
            pass
        # drop words inside removed gaps
        inside = any(s - 0.05 <= w["start"] < e for (s, e) in removed)
        if inside:
            if cur_words:
                events.append((cur_s, cur_e, " ".join(cur_words)))
                cur_words = []
            continue
        cs, ce = clip_time(w["start"]), clip_time(w["end"])
        if cur_words and cs - cur_e > 0.45:  # new caption line
            events.append((cur_s, cur_e, " ".join(cur_words)))
            cur_words = []
        if not cur_words:
            cur_s, cur_e = cs, ce
        else:
            cur_e = ce
        cur_words.append(w["word"].strip(" '’.,"))
    if cur_words:
        events.append((cur_s, cur_e, " ".join(cur_words)))

    def esc(t):
        return t.replace("{", "(").replace("}", ")").replace("\\", "")

    text = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
            "[V4+ Styles]\n")
    text += (f"Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
             f"OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
             f"ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
             f"Alignment, MarginL, MarginR, MarginV, Encoding\n")
    accent = brand.get("accent") if brand else None
    colour = f"&H{accent}FFFF" if accent else "&H00FFFF00"
    text += (f"Style: Cap,{st['font']},{st['size']},{st['color']},&H00000000,"
             f"{colour},&H80000000,{1 if st['bold'] else 0},0,0,0,100,100,0,0,1,"
             f"{st['outline']},{st['shadow']},2,{st['margin']},{st['margin']},"
             f"{st['margin']},1\n")
    text += "\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    for (cs, ce, cap) in events:
        if ce <= cs:
            ce = cs + 0.5
        s, e = _ass_ts(cs), _ass_ts(ce)
        display = cap.upper() if st["upper"] else cap
        if st["upper"] and len(display) > 26:
            # word emphasis: keep caps but that's fine
            pass
        text += f"Dialogue: 0,{s},{e},Cap,,0,0,0,,{esc(display)}\n"
    return text


def _ass_ts(sec):
    sec = max(0, sec)
    h = int(sec // 3600); m = int(sec % 3600 // 60); s = int(sec % 60); c = int((sec % 1) * 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"


# ---------------------------------------------------------------- segments
def render_segment(source, rs, re, crop, out, progress_cb, total, offset):
    x, y, cw, ch = crop
    args = ["-ss", str(rs), "-to", str(re), "-i", source,
            "-vf", (f"crop={cw}:{ch}:{x}:{y},scale={RENDER_WIDTH}:{RENDER_HEIGHT}"
                    f":flags=lanczos,fps={FPS},setsar=1"),
            "-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "128k", out]
    run_ffmpeg(args, progress_cb=lambda p: progress_cb(offset + p * (re - rs) / total))


def concat_segments(seg_list, out):
    listf = tempfile.mktemp(suffix=".txt")
    with open(listf, "w") as f:
        for s in seg_list:
            f.write(f"file '{s}'\n")
    run_ffmpeg(["-f", "concat", "-safe", "0", "-i", listf, "-c", "copy", out])
    Path(listf).unlink(missing_ok=True)


# ---------------------------------------------------------------- audio/music
def _duck_music(music_path, speech_path, music_vol):
    """Mix speech + ducked music, normalize. Returns wav path."""
    out = tempfile.mktemp(suffix=".wav")
    args = ["-i", speech_path, "-i", music_path,
            "-filter_complex",
            ("[1:a]volume={mv}[m];"
             "[0:a][m]sidechaincompress=threshold=0.05:ratio=6:attack=10:release=300:makeup=1[duck];"
             "[0:a][duck]amix=inputs=2:duration=first:normalize=0[mix];"
             "[mix]loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100[out]").format(mv=music_vol),
            "-map", "[out]", "-y", out]
    run_ffmpeg(args)
    return out


# ---------------------------------------------------------------- orchestrator
def render_clip(source, probe_info, clip, config, out_path, music_path=None,
                progress_cb=None, log_path=None, brand=None):
    start, end = clip["start"], clip["end"]
    # ensure we know source dimensions (needed for smart crop)
    if not probe_info or not probe_info.get("width"):
        pi = probe(source)
        for s in pi.get("streams", []):
            if s.get("codec_type") == "video":
                probe_info = {"width": s["width"], "height": s["height"]}
                break
    if not probe_info:
        probe_info = {"width": 1920, "height": 1080}
    intensity = config.get("editing_intensity", "moderate")
    style_key = config.get("caption_style", "dynamic")
    music_vol = config.get("music_volume", 0.16)

    steps = ["Detecting silence", "Smart reframing", "Rendering segments",
             "Assembling", "Captioning", "Audio", "Encoding"]
    def step(i, sub=0, span=1.0):
        if progress_cb:
            progress_cb((i + sub * span) / len(steps) * 100)

    step(0)
    gaps = detect_silence(source, start, end)
    ranges = retained_ranges(start, end, gaps, intensity)

    step(1)
    crop = smart_crop_offset(source, start, end, probe_info)

    tmpdir = tempfile.mkdtemp(prefix="clip_")
    try:
        step(2)
        segs = []
        total_dur = sum(re - rs for (rs, re) in ranges)
        acc = 0.0
        for idx, (rs, re) in enumerate(ranges):
            seg = os.path.join(tmpdir, f"seg{idx}.mp4")
            render_segment(source, rs, re, crop, seg, progress_cb, total_dur, acc)
            segs.append(seg)
            acc += re - rs

        step(3)
        edited = os.path.join(tmpdir, "edited.mp4")
        concat_segments(segs, edited)

        # captions resync (words is a flat [{word,start,end}] list in source time)
        step(4, sub=0.3, span=0.4)
        words = clip.get("words", [])
        ass = build_ass(words, gaps, start, style_key, brand)
        ass_path = os.path.join(tmpdir, "caps.ass")
        Path(ass_path).write_text(ass, encoding="utf-8")

        step(4, sub=1, span=0.4)

        # final encode with subtitles + audio
        args = [FFMPEG, "-y", "-hide_banner", "-i", edited]
        fcmds = [f"subtitles='{_esc_path(ass_path)}'", "setsar=1"]
        if brand and brand.get("watermark"):
            pass
        if music_path:
            step(6, sub=0.2, span=0.5)
            args += ["-i", music_path]
            ducked = _duck_music(music_path, edited, music_vol)
            # encode final: use ducked audio + subtitled video
            run_ffmpeg([
                "-y", "-hide_banner", "-i", edited, "-i", ducked,
                "-vf", ",".join(fcmds),
                "-map", "0:v", "-map", "1:a",
                "-c:v", "libx264", "-preset", "medium", "-crf", str(EXPORT_CRF),
                "-pix_fmt", "yuv420p", "-r", str(FPS),
                "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
                "-movflags", "+faststart", "-shortest", out_path,
            ], progress_cb, total_seconds=(end - start), log_path=log_path)
            return out_path

        # no music: subtitles + normalize audio from edited
        args += ["-vf", ",".join(fcmds),
                 "-af", "afftdn=nf=-25,loudnorm=I=-16:TP=-1.5:LRA=11",
                 "-c:v", "libx264", "-preset", "medium", "-crf", str(EXPORT_CRF),
                 "-pix_fmt", "yuv420p", "-r", str(FPS),
                 "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
                 "-movflags", "+faststart", "-shortest", out_path]
        step(6, sub=0.3, span=0.7)
        run_ffmpeg(args, progress_cb, total_seconds=(end - start), log_path=log_path)
        return out_path
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)


def _flatten_words(segments):
    words = []
    for s in segments:
        for w in s.get("words", []):
            words.append({"word": w["word"], "start": w["start"], "end": w["end"]})
    words.sort(key=lambda x: x["start"])
    return words


def _esc_path(p):
    return str(p).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
