"""SQLite persistence layer with a clean, scalable relational schema."""
import sqlite3, json, threading, time, uuid
from datetime import datetime, timezone
from .config import DB_PATH

_lock = threading.Lock()
_db_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT,
  plan TEXT DEFAULT 'free',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  plan TEXT NOT NULL,
  credits_remaining REAL DEFAULT 0,
  credits_used REAL DEFAULT 0,
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS usage (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  metric TEXT NOT NULL,
  amount REAL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  source_url TEXT,
  status TEXT DEFAULT 'draft',
  config_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS source_videos (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id),
  user_id TEXT NOT NULL,
  filename TEXT,
  path TEXT,
  url TEXT,
  size_bytes INTEGER DEFAULT 0,
  duration REAL,
  width INTEGER, height INTEGER,
  status TEXT DEFAULT 'pending',
  error TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transcripts (
  id TEXT PRIMARY KEY,
  source_video_id TEXT NOT NULL REFERENCES source_videos(id),
  language TEXT,
  duration REAL,
  text TEXT,
  segments_json TEXT,   -- full whisper segments with per-word timing
  status TEXT DEFAULT 'processing',
  error TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clips (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id),
  source_video_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  start_ts REAL NOT NULL,
  end_ts REAL NOT NULL,
  duration REAL,
  status TEXT DEFAULT 'processing',  -- processing|ready|queued|scheduled|published|failed|needs_review|draft
  score REAL,
  score_label TEXT,
  hook_snapshot TEXT,
  video_path TEXT,
  thumbnail_path TEXT,
  transcript TEXT,
  editing_style TEXT,
  caption_style TEXT,
  music_style TEXT,
  reason TEXT,
  requires_approval INTEGER DEFAULT 0,
  position INTEGER DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clip_scores (
  id TEXT PRIMARY KEY,
  clip_id TEXT NOT NULL REFERENCES clips(id),
  hook_strength REAL, curiosity REAL, emotional_intensity REAL,
  entertainment REAL, information REAL, standalone_context REAL,
  pacing REAL, shareability REAL, originality REAL, ending_quality REAL,
  overall REAL
);
CREATE TABLE IF NOT EXISTS clip_metadata (
  id TEXT PRIMARY KEY,
  clip_id TEXT NOT NULL REFERENCES clips(id),
  platform TEXT NOT NULL,           -- youtube_shorts|tiktok|instagram_reels
  title TEXT, description TEXT, hashtags TEXT, cta TEXT, keywords TEXT,
  status TEXT DEFAULT 'generated',
  created_at TEXT NOT NULL,
  UNIQUE(clip_id, platform)
);
CREATE TABLE IF NOT EXISTS render_jobs (
  id TEXT PRIMARY KEY,
  clip_id TEXT NOT NULL REFERENCES clips(id),
  project_id TEXT, user_id TEXT,
  status TEXT DEFAULT 'pending',    -- pending|running|done|failed|retrying
  attempts INTEGER DEFAULT 0,
  progress REAL DEFAULT 0,
  stage TEXT DEFAULT 'queued',
  output_path TEXT,
  error TEXT,
  log TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS social_accounts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  platform TEXT NOT NULL,           -- youtube|tiktok|instagram
  display_name TEXT,
  handle TEXT,
  status TEXT DEFAULT 'connected',
  token_enc TEXT,
  expires_at TEXT,
  error TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS automations (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  source_url TEXT,
  trigger_type TEXT DEFAULT 'new_video',
  config_json TEXT DEFAULT '{}',
  enabled INTEGER DEFAULT 0,
  last_check TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS publishing_jobs (
  id TEXT PRIMARY KEY,
  clip_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  platform TEXT NOT NULL,
  account_id TEXT,
  status TEXT DEFAULT 'queued',    -- queued|processing|scheduled|published|failed|needs_review
  scheduled_at TEXT,
  published_at TEXT,
  attempts INTEGER DEFAULT 0,
  error TEXT,
  external_id TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS brand_kits (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT DEFAULT 'My Brand',
  config_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  scope TEXT, entity TEXT, entity_id TEXT, payload TEXT,
  created_at TEXT NOT NULL
);
"""


def _connect():
    c = getattr(_db_local, "conn", None)
    if c is None:
        c = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        _db_local.conn = c
    return c


def init_db():
    conn = _connect()
    conn.executescript(SCHEMA)
    conn.commit()


def now():
    return datetime.now(timezone.utc).isoformat()


def new_id():
    return uuid.uuid4().hex


def query(sql, params=()):
    conn = _connect()
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def get_one(sql, params=()):
    rows = query(sql, params)
    return rows[0] if rows else None


def execute(sql, params=()):
    conn = _connect()
    with _lock:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid


def insert(table, data):
    keys = list(data.keys())
    sql = f"INSERT INTO {table} ({','.join(keys)}) VALUES ({','.join('?'*len(keys))})"
    vals = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in data.values()]
    execute(sql, vals)


def update(table, data, where, where_params=()):
    sets = ",".join(f"{k}=?" for k in data.keys())
    vals = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in data.values()]
    execute(f"UPDATE {table} SET {sets} WHERE {where}", vals + list(where_params))


def record_usage(user_id, metric, amount):
    insert("usage", {"id": new_id(), "user_id": user_id, "metric": metric,
                     "amount": amount, "created_at": now()})
    execute("UPDATE subscriptions SET credits_used=credits_used+? WHERE user_id=?",
            (amount, user_id))


def emit(scope, entity, entity_id, payload=None):
    insert("events", {"id": new_id(), "scope": scope, "entity": entity,
                      "entity_id": entity_id,
                      "payload": json.dumps(payload or {}), "created_at": now()})


def recent_events(entity=None, entity_id=None, limit=200):
    sql = "SELECT * FROM events WHERE 1=1"
    p = []
    if entity:
        sql += " AND entity=?"; p.append(entity)
    if entity_id:
        sql += " AND entity_id=?"; p.append(entity_id)
    sql += " ORDER BY created_at DESC LIMIT ?"
    p.append(limit)
    return query(sql, p)
