"""Background job queue with retries + a shared progress registry for SSE.

A production deployment swaps this in-process queue for Celery/RQ/Arq + Redis.
The Worker API is kept identical so the swap is internal to this module.
"""
import queue, threading, time, traceback, json, asyncio
from . import db

MAX_ATTEMPTS = 3
RETRY_BASE_WAIT = 3  # seconds

_task_queue = queue.Queue()
_progress = {}          # job_id -> dict(state, stage, progress, message)
_progress_lock = threading.Lock()
_sse_subs = []          # list of asyncio.Queue for connected SSE clients


# ---------------------------------------------------------------- progress
def set_progress(job_id, stage=None, progress=None, message=None, state=None):
    with _progress_lock:
        p = _progress.setdefault(job_id, {"state": "pending", "stage": "queued",
                                          "progress": 0, "message": "", "ts": time.time()})
        if stage is not None:
            p["stage"] = stage
        if progress is not None:
            p["progress"] = progress
        if message is not None:
            p["message"] = message
        if state is not None:
            p["state"] = state
        p["ts"] = time.time()
        payload = {"job_id": job_id, **p}
    _broadcast({"type": "progress", **payload})
    return payload


def get_progress(job_id):
    with _progress_lock:
        return _progress.get(job_id)


def _broadcast(payload):
    for q in list(_sse_subs):
        try:
            q.put_nowait(payload)
        except Exception:
            pass


def publish_event(entity_id, payload, scope="project", entity="project"):
    """Emit a live event (e.g. pipeline stage progress) to SSE subscribers."""
    _broadcast({"type": "event", "scope": scope, "entity": entity,
                "entity_id": entity_id, **payload})


def _matches_filters(payload, scope, entity, entity_id):
    if scope is not None and payload.get("scope") != scope:
        return False
    if entity is not None and payload.get("entity") != entity:
        return False
    if entity_id is not None and payload.get("entity_id") != entity_id:
        return False
    return True


async def sse_stream(scope=None, entity=None, entity_id=None, replay=None):
    """Async generator yielding events to a connected SSE client.
    Optionally filter by scope/entity/entity_id and replay persisted events."""
    if replay:
        for ev in db.recent_events(entity=entity, entity_id=entity_id, limit=100):
            yield f"data: {json.dumps({**json.loads(ev.get('payload') or '{}'), 'scope': ev['scope'], 'entity': ev['entity'], 'entity_id': ev['entity_id']})}\n\n"
    q = asyncio.Queue(maxsize=200)
    _sse_subs.append(q)
    try:
        yield ": connected\n\n"
        while True:
            try:
                item = await asyncio.wait_for(q.get(), timeout=15)
                if _matches_filters(item, scope, entity, entity_id):
                    yield f"data: {json.dumps(item)}\n\n"
            except asyncio.TimeoutError:
                yield ": ping\n\n"
    finally:
        if q in _sse_subs:
            _sse_subs.remove(q)


# ------------------------------------------------------------------ queue
class Task:
    def __init__(self, kind, job_id, fn, *args, persist=(), **kwargs):
        self.kind = kind
        self.job_id = job_id
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.persist = persist  # names of kwargs to persist as job attributes

    def run(self):
        return self.fn(*self.args, **self.kwargs)


def enqueue(kind, job_id, fn, *args, **kwargs):
    _task_queue.put(Task(kind, job_id, fn, *args, **kwargs))


def _worker_loop():
    while True:
        task = _task_queue.get()
        if task is None:
            break
        attempts = 0
        while True:
            attempts += 1
            set_progress(task.job_id, state="running", stage="started",
                         progress=0, message=f"Attempt {attempts}")
            persist_row = _load_persist(task)
            if persist_row is not None:
                persist_row.update(status="running", attempts=attempts)
                db.update(persist_row["_table"], persist_row, "id=?", (persist_row["id"],))
            try:
                task.run()
                set_progress(task.job_id, state="done", progress=100,
                             message="Complete")
                _mark_done(task)
                break
            except Exception as e:
                traceback.print_exc()
                set_progress(task.job_id, state="failed", message=str(e))
                if attempts < MAX_ATTEMPTS:
                    set_progress(task.job_id, state="retrying",
                                 message=f"Retrying ({attempts}/{MAX_ATTEMPTS}): {e}")
                    _mark_retry(task, attempts)
                    time.sleep(RETRY_BASE_WAIT * attempts)
                else:
                    _mark_failed(task, str(e))
                    break


def _load_persist(task):
    if not task.persist:
        return None
    d = {}
    for name in task.persist:
        if name in task.kwargs:
            d[name] = task.kwargs[name]
    if "table" not in d:
        return None
    d["_table"] = d.pop("table")
    row = db.get_one(f"SELECT * FROM {d['_table']} WHERE id=?", (d.pop("id"),))
    return row


def _mark_done(task):
    _persist_status(task, "done")


def _mark_retry(task, attempts):
    _persist_status(task, "retrying")
    set_progress(task.job_id, stage="queued", progress=0,
                 message=f"Retry {attempts} scheduled")


def _mark_failed(task, err):
    _persist_status(task, "failed")
    set_progress(task.job_id, state="failed", message=str(err))


def _persist_status(task, status):
    if not task.persist:
        return
    row = _load_persist(task)
    if row is None:
        return
    table = row.pop("_table")
    if status == "done":
        set_progress(task.job_id, state="done", progress=100)
    try:
        db.update(table, {"status": status}, "id=?", (row["id"],))
    except Exception:
        pass


_workers = []


def start_workers(n=2):
    global _workers
    for _ in range(n):
        t = threading.Thread(target=_worker_loop, daemon=True)
        t.start()
        _workers.append(t)
